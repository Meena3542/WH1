# Wellhead

An oil and gas learning and news hub: interactive tutorials, an industry news
dashboard, competitor news, and an AI Hub.

## Two ways to run it

**1. Tutorials only, zero setup.** Double-click `standalone/wellhead.html`.
It runs in any modern browser with no server and no install. The news feeds
show clearly labelled demo items in this mode.

**2. With real news.** Needs Node.js 18 or newer.

    cd collector
    npm install
    npm start
    # open http://localhost:8787   (diagnostics: http://localhost:8787/status)

The collector polls the news sources every hour, files articles by date, and
serves the app and its data from one address. See `collector/README.md`,
especially "Which sources are actually confirmed working".

## What is inside

- `standalone/wellhead.html` : the whole app in one file (demo news).
- `collector/` : the Node.js news collector, which also serves the live app.
- `source/` : the app's readable source (one file per tutorial group). Edit
  these, then run `source/build.sh` to regenerate both HTML files.

## Tutorials: 12 of 55 built

Well fundamentals (5 of 5), Reservoir and inflow (5 of 5), plus choke
performance and model predictive control. The other 43 appear on the
Tutorials page marked "Planned". Domains still to build: Drilling and
completions, most of Production engineering, Facilities and flow assurance,
Well testing and logging, most of Instrumentation and control, Optimisation
and numerical methods, AI and machine learning, Economics/safety/digital.

## Honest status

- Tested: all 12 tutorials and all six pages were exercised in an automated
  browser-like test (every slider and button), with no errors.
- Tested: the collector's parsing, tagging, deduplication, storage and API
  against stand-in feeds.
- Fixed from real-world feedback: the `ogiq` source was wrongly pointed at
  a local test address, and the collector's User-Agent was getting
  blocked by several publishers. Both fixed — see
  `collector/README.md`, "Two real bugs found and fixed after the first
  run". Also added: an AI Hub filter for energy/industrial-relevant AI
  news, and a dedicated arXiv source searching for AI-in-energy research.
- Not tested: fetching from the real news sites, which the build environment
  could not reach. Check `/status` after your first run and fix any source
  marked as an error in `collector/sources.js`.
- Worked examples were calculated by script, but check formulas and constants
  against your own references before using them for design.
