# Wellhead collector

This is the piece that makes the Wellhead news feeds real instead of demo
data. It is a small Node.js server that:

1. Reads a list of RSS/Atom feeds (and one Google-News-style sitemap) every
   hour.
2. Tags each article with a topic, and — for oil and gas articles — checks
   whether it names a Honeywell competitor.
3. Stores everything in a local JSON file, one entry per article, so it can
   be browsed by the day it was published (the app's Archive page).
4. Serves the results at `/api/feed`, and serves the Wellhead app itself at
   `/`, so the whole thing runs from one address with no cross-origin setup.

## Why this has to run somewhere, not inside the claude.ai page

The Wellhead app you saw published as a claude.ai artifact runs inside a
locked-down browser sandbox that is not allowed to call outside servers.
That is a deliberate security boundary of the artifact platform, not a bug
in this project. So the published claude.ai link will always show demo
data. To see real news, run this collector and open the app **from here**
(`http://localhost:8787` or wherever you deploy it) instead of the
claude.ai link.

## Which sources are actually confirmed working

I could only reach a handful of domains from the sandbox I built this in
(package registries, GitHub — not news sites), so I fetched and checked
what I could and was honest about what I couldn't. In `sources.js`:

- **`verified: true`** — I fetched this URL directly and confirmed it
  returns real, parseable feed content: Oil & Gas IQ (two feeds), the
  OilPrice.com news sitemap, and the arXiv API searches.
- **`verified: 'likely'`** — found via FeedSpot's RSS feed database (which
  lists outlets' actual current feed URLs, not a guess), but I haven't
  fetched it myself. Oil & Gas Journal and World Oil are in this category.
- **`verified: false`** — a plausible feed URL for that outlet that I was
  not able to check at all. Some of these will work as-is; some outlets
  have moved or gated their feeds and the URL will need fixing.

Run the server and open `/status` in a browser — it lists every source,
whether its last fetch succeeded, and the error if not. Fix any URL marked
❌ directly in `sources.js` and restart. A 403 or 404 there almost always
means the feed address has changed, or the site is blocking the request —
see the next section.

### Two real bugs found and fixed after the first run

A person actually running this reported almost every oil & gas source
failing except two, no competitor news, and AI news with no connection to
energy. Both turned out to be real, specific problems, not vague
flakiness:

1. **The `ogiq` source was pointing at a local test address
   (`localhost:9911`)** left over from my own testing, not a real
   oil-and-gas-IQ address. Fixed — it now points at the real feed.
2. **The collector's own User-Agent string (`WellheadCollector/1.0`) was
   getting blocked.** Many publishers' firewalls reject any request that
   doesn't look like an ordinary browser. `lib/fetch.js` now sends a
   standard Chrome User-Agent, which is the single most common fix for a
   source that returns HTTP 403.

If a source is still failing after both of these, open `/status`: a 403
there means the site is blocking the request outright (try opening the
feed URL in your own browser — if it loads there but not here, the site
has stricter bot-detection than a User-Agent string alone gets past); a
404 means the URL has moved and needs updating in `sources.js`.

### Competitor news depends on the oil & gas sources working

There's no separate competitor news wire — every article collected for
the oil & gas feed is scanned for the nine watched company names. With
only one or two oil & gas sources actually returning articles, the odds
of any of them mentioning a specific competitor by name in a given hour
are low. This should resolve itself as more oil & gas sources come
online; it isn't a separate bug to chase.

### AI Hub: global AI news, plus a filter for energy-relevant AI

The AI Hub was built to show AI news from across the whole field (that
was the original brief: "latest AI news/innovation/ideas across the
globe"), so most of it won't mention oil and gas — that's expected, not
broken. Two things now narrow it down when that's what you want:

- A dedicated source, `arxivenergy`, that searches arXiv specifically for
  AI/ML papers about energy, reservoirs, drilling and petroleum, instead
  of hoping general AI news happens to mention the industry.
- A **"⚡ Energy & industrial AI only"** toggle in the AI Hub's News tab,
  which filters down to articles whose text mentions oil, gas, energy,
  drilling, industrial automation and similar terms (`lib/tag.js`,
  `isIndustryRelevant`). Items that match are also marked with an
  "⚡ Energy/industrial" tag even with the toggle off.

## Setup

```bash
npm install
npm start
```

Then open `http://localhost:8787/`. The first poll runs immediately on
startup, and again every hour on the hour after that (`node-cron`, pattern
`0 * * * *`). `/status` shows the last poll time and a poll-now button.

Environment variables (optional, in a `.env` file):

```
PORT=8787
```

## Files

- `server.js` — Express app: serves the front end, `/api/feed`,
  `/api/status`, `/status` (a human-readable diagnostics page), and the
  hourly cron job.
- `sources.js` — the editable list of feeds, the Honeywell competitor
  watchlist, and the keyword tables used for topic and region tagging.
  This is the file you'll come back to most.
- `lib/fetch.js` — fetches and parses RSS/Atom feeds and the one
  Google-News-sitemap-style source, with a timeout so one slow source
  can't stall the whole poll.
- `lib/tag.js` — plain keyword matching for topic, company and region.
  It's deliberately simple; see "Improving the tagging" below.
- `lib/store.js` — the JSON-file database: deduplication, a 120-day
  retention window, and an 8,000-item cap so the file can't grow forever.
- `lib/poll.js` — runs one full cycle: fetch every source, tag each
  article, store it, and — separately — scan oil-and-gas articles for
  competitor mentions to populate the competitor feed.
- `public/index.html` — the Wellhead app, pointed at `/api/feed` instead
  of demo data (`LIVE_API` near the top of its script).
- `data/store.json` — created on first run. Delete it to start the
  archive over.

## How the competitor feed works

There's no separate "Honeywell competitor" news wire, so the collector
builds one: every article collected for the oil & gas feed is checked
against `COMPANIES` in `sources.js` (name and a few aliases). Any match is
copied into the competitor feed, tagged with that company. Edit
`COMPANIES` to add or remove companies — no other code needs to change.

## Improving the tagging

Topic and region tagging is plain keyword matching (`lib/tag.js`), checked
in the order given in `sources.js` — first match wins, so put more
specific phrases earlier in the list. This is easy to reason about and
good enough to file articles usefully, but it will occasionally mistag
something. Two straightforward upgrades if that matters to you later:
swap the keyword table for a call to a classification model, or add a
manual override list keyed by source domain.

## Known limitations, stated plainly

- RSS feeds only expose an outlet's most recent items (usually the last
  20–50), not their history. The date-wise archive builds up from when you
  start running this collector; it cannot backfill months of past news.
- The region tag on AI news is a keyword guess, not sourced from the
  article's actual dateline. Treat it as approximate.
- The JSON-file store is fine for one server and moderate volume. If you
  outgrow it (many more sources, multiple servers), move `lib/store.js` to
  a real database — the function signatures are small enough to reimplement
  against Postgres or SQLite without touching `poll.js`.
- This has not been run against the live internet — only against local
  test fixtures standing in for real feeds, because this environment's
  network is restricted to package registries. Expect to spend a little
  time on `/status` after the first real run fixing any ❌ source URLs.
