'use strict';
require('dotenv').config();
const express = require('express');
const path = require('path');
const cron = require('node-cron');
const store = require('./lib/store');
const { pollAll } = require('./lib/poll');

const PORT = process.env.PORT || 8787;
const app = express();

app.use(express.static(path.join(__dirname, 'public')));

app.get('/api/feed', (req, res) => {
  res.json(store.allItems());
});

app.get('/api/status', (req, res) => {
  res.json(store.status());
});

app.get('/status', (req, res) => {
  const st = store.status();
  const rows = Object.entries(st.sources).sort((a, b) => a[0].localeCompare(b[0]))
    .map(([id, s]) => `<tr><td>${id}</td><td>${s.ok ? '\u2705 ok' : '\u274c error'}</td>
      <td>${new Date(s.at).toLocaleString()}</td><td>${escapeHtml(String(s.info))}</td></tr>`).join('');
  res.type('html').send(`<!doctype html><meta charset="utf-8">
    <title>Wellhead collector status</title>
    <style>body{font-family:system-ui,sans-serif;margin:2rem;color:#13212B}
    table{border-collapse:collapse;width:100%;max-width:900px}
    th,td{border:1px solid #ccd;padding:6px 10px;text-align:left;font-size:14px}
    th{background:#eef}</style>
    <h1>Wellhead collector</h1>
    <p>Last poll: ${st.lastPoll ? new Date(st.lastPoll).toLocaleString() : 'not yet run'}.
    Items stored: ${st.itemCount}. <a href="/api/feed">Raw feed JSON</a>. <a href="/">Open the app</a>.</p>
    <p>Any source marked \u274c needs its URL fixed in <code>sources.js</code> \u2014 see the
    comment at the top of that file for which ones are already verified.</p>
    <button onclick="fetch('/api/poll',{method:'POST'}).then(()=>location.reload())">Poll now</button>
    <table><tr><th>Source id</th><th>Status</th><th>Last attempt</th><th>Detail</th></tr>${rows}</table>`);
});

app.post('/api/poll', async (req, res) => {
  try {
    res.json(await pollAll());
  } catch (e) {
    res.status(500).json({ error: e.message || String(e) });
  }
});

function escapeHtml(s) {
  return s.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

app.listen(PORT, () => {
  console.log(`Wellhead collector running.`);
  console.log(`  App:    http://localhost:${PORT}/`);
  console.log(`  Status: http://localhost:${PORT}/status`);
});

pollAll().then(r => console.log('Initial poll:', JSON.stringify(r.added)))
  .catch(e => console.error('Initial poll failed:', e));

cron.schedule('0 * * * *', () => {
  console.log('Hourly poll starting\u2026');
  pollAll().then(r => console.log('Hourly poll done:', JSON.stringify(r.added)))
    .catch(e => console.error('Hourly poll failed:', e));
});
