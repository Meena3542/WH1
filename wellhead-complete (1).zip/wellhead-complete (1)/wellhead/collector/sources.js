'use strict';
/* =======================================================================
   Source configuration for the Wellhead collector.
   -----------------------------------------------------------------------
   verified:true  = I fetched this URL while building the collector and
                    confirmed it returns real, parseable feed content.
   verified:false = a plausible URL for that outlet, but I could NOT check
                    it (this sandbox can only reach npm/GitHub-type
                    domains, not news sites). Open /api/status after your
                    first run: any source marked "error" there needs its
                    url fixed here. This is expected on first run for the
                    unverified ones — replace the url with the outlet's
                    real feed and restart.
   kind: 'rss'          RSS 2.0 or Atom, parsed with rss-parser.
   kind: 'newsSitemap'  Google News XML sitemap, parsed by lib/fetch.js.
   id:  must match an id in wellhead's SRC.og / SRC.ai lists (public/wellhead.html)
        so the app shows the right outlet name and homepage link.
   ======================================================================= */

const OG_SOURCES = [
  { id: 'ogiq',    name: 'Oil & Gas IQ',           kind: 'rss',
    url: 'https://www.oilandgasiq.com/rss/editorials', verified: true },
  { id: 'ogiq2',   name: 'Oil & Gas IQ \u2014 Columns', kind: 'rss',
    url: 'https://www.oilandgasiq.com/rss/columns', verified: true, srcIdAlias: 'ogiq' },
  { id: 'oilprice', name: 'OilPrice.com',          kind: 'newsSitemap',
    url: 'https://oilprice.com/googlenews.xml', verified: true },
  // Found via FeedSpot's RSS database (a feed directory that lists each
  // outlet's actual, currently-working feed URL) rather than guessed —
  // higher confidence than the "false" ones below, but still not fetched
  // live by me, so check /status after your first run regardless.
  { id: 'ogj',     name: 'Oil & Gas Journal',      kind: 'rss', verified: 'likely',
    url: 'https://www.ogj.com/__rss/website-scheduled-content.xml?input=%7B%22sectionAlias%22:%22general-interest%22%7D' },
  { id: 'worldoil', name: 'World Oil',             kind: 'rss', verified: 'likely',
    url: 'https://www.worldoil.com/rss?feed=news' },
  { id: 'rigzone', name: 'Rigzone',                kind: 'rss',
    url: 'https://www.rigzone.com/news/rss/rigzone_latest.aspx', verified: false },
  { id: 'offtech', name: 'Offshore Technology',    kind: 'rss',
    url: 'https://www.offshore-technology.com/feed/', verified: false },
  { id: 'jpt',     name: 'Journal of Petroleum Technology', kind: 'rss',
    url: 'https://jpt.spe.org/rss.xml', verified: false },
  { id: 'hart',    name: 'Hart Energy',            kind: 'rss',
    url: 'https://www.hartenergy.com/rss.xml', verified: false },
  { id: 'upstream', name: 'Upstream',              kind: 'rss',
    url: 'https://www.upstreamonline.com/rss', verified: false }
];

const AI_SOURCES = [
  { id: 'arxiv', name: 'arXiv cs.AI', kind: 'rss', verified: true,
    url: 'http://export.arxiv.org/api/query?search_query=cat:cs.AI&sortBy=submittedDate&sortOrder=descending&max_results=40' },
  { id: 'arxivlg', name: 'arXiv cs.LG', kind: 'rss', verified: true, srcIdAlias: 'arxiv',
    url: 'http://export.arxiv.org/api/query?search_query=cat:cs.LG&sortBy=submittedDate&sortOrder=descending&max_results=40' },
  // Same arXiv API, but searching specifically for AI/ML papers about
  // energy, reservoirs, drilling etc. This is what actually surfaces
  // oil-and-gas-relevant AI research, rather than hoping general AI news
  // happens to mention the industry.
  { id: 'arxivenergy', name: 'arXiv (AI + energy)', kind: 'rss', verified: true, srcIdAlias: 'arxiv',
    url: 'http://export.arxiv.org/api/query?search_query=(cat:cs.LG+OR+cat:cs.AI)+AND+(abs:energy+OR+abs:reservoir+OR+abs:drilling+OR+abs:%22oil+and+gas%22+OR+abs:petroleum)&sortBy=submittedDate&sortOrder=descending&max_results=30' },
  { id: 'anthropic', name: 'Anthropic News', kind: 'rss', verified: false,
    url: 'https://www.anthropic.com/news/rss.xml' },
  { id: 'openai', name: 'OpenAI News', kind: 'rss', verified: false,
    url: 'https://openai.com/news/rss.xml' },
  { id: 'deepmind', name: 'Google DeepMind Blog', kind: 'rss', verified: false,
    url: 'https://deepmind.google/blog/rss.xml' },
  { id: 'hf', name: 'Hugging Face Blog', kind: 'rss', verified: false,
    url: 'https://huggingface.co/blog/feed.xml' },
  { id: 'mit', name: 'MIT Technology Review', kind: 'rss', verified: false,
    url: 'https://www.technologyreview.com/feed/' },
  { id: 'batch', name: 'The Batch', kind: 'rss', verified: false,
    url: 'https://www.deeplearning.ai/the-batch/feed/' },
  { id: 'msr', name: 'Microsoft Research Blog', kind: 'rss', verified: false,
    url: 'https://www.microsoft.com/en-us/research/feed/' }
];

/* Honeywell competitors, in oil/gas and industrial automation. Edit freely. */
const COMPANIES = [
  { id: 'emerson', name: 'Emerson', match: ['emerson'] },
  { id: 'yokogawa', name: 'Yokogawa', match: ['yokogawa'] },
  { id: 'abb', name: 'ABB', match: [' abb ', 'abb ltd', 'abb group'] },
  { id: 'siemens', name: 'Siemens', match: ['siemens'] },
  { id: 'schneider', name: 'Schneider Electric / AVEVA', match: ['schneider electric', 'aveva'] },
  { id: 'rockwell', name: 'Rockwell Automation', match: ['rockwell automation'] },
  { id: 'bakerhughes', name: 'Baker Hughes', match: ['baker hughes'] },
  { id: 'slb', name: 'SLB', match: ['slb', 'schlumberger'] },
  { id: 'halliburton', name: 'Halliburton', match: ['halliburton'] }
];

/* First keyword match wins; order matters. Keep phrases lowercase. */
const TOPIC_KEYWORDS_OG = [
  ['Drilling automation', ['automated drilling', 'drilling automation', 'autonomous rig']],
  ['Well integrity', ['well integrity', 'well control', 'blowout']],
  ['Methane and emissions', ['methane', 'flaring', 'emissions', 'carbon capture']],
  ['Digital twins', ['digital twin']],
  ['Subsea systems', ['subsea']],
  ['Offshore projects', ['offshore', 'fpso', 'platform']],
  ['Artificial lift', ['artificial lift', 'gas lift', 'esp pump']],
  ['Unconventional wells', ['shale', 'fracking', 'hydraulic fracturing', 'unconventional']],
  ['Gas processing', ['lng', 'gas processing', 'liquefied natural gas']],
  ['Regulation and policy', ['regulation', 'policy', 'sanctions', 'opec']],
  ['Market and prices', ['crude price', 'oil price', 'wti', 'brent', 'barrel']],
  ['Production optimization', ['production optimi', 'output', 'field development']]
];
const TOPIC_KEYWORDS_AI = [
  // Most specific phrases first, since the first match wins.
  ['Physics-informed ML', ['physics-informed', 'physics informed']],
  ['Explainable AI', ['explainab', 'interpretab', 'shap value']],
  ['AI chips and compute', ['chip', 'gpu', 'nvidia', 'tpu']],
  ['Open-source tool', ['open source', 'open-source', 'open weights']],
  ['Agentic AI in industry', ['agent', 'agentic']],
  ['AI safety and policy', ['safety', 'regulation', 'policy', 'governance']],
  ['New model release', ['releases', 'launch', 'unveils', 'new model']],
  ['Enterprise adoption', ['enterprise', 'adoption', 'deploy']],
  ['Time-series forecasting', ['time series', 'forecasting']],
  ['Research paper', ['arxiv', 'paper', 'study finds']]
];
const REGION_KEYWORDS = [
  ['China', ['china', 'beijing', 'shanghai']],
  ['India', ['india', 'mumbai', 'delhi']],
  ['Europe', ['europe', 'eu ', 'brussels', 'uk ', 'britain', 'germany', 'france']],
  ['Middle East', ['middle east', 'saudi', 'uae', 'qatar', 'gulf']],
  ['North America', ['united states', 'u.s.', 'usa', 'texas', 'canada', 'permian']]
];

module.exports = { OG_SOURCES, AI_SOURCES, COMPANIES, TOPIC_KEYWORDS_OG, TOPIC_KEYWORDS_AI, REGION_KEYWORDS };
