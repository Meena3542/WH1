'use strict';
/* ---------- helpers ---------- */
const $=(s,r=document)=>r.querySelector(s);
const $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt=(v,d=0)=>Number(v).toLocaleString('en-US',{minimumFractionDigits:d,maximumFractionDigits:d});
const clamp=(v,a,b)=>Math.min(b,Math.max(a,v));
const store={
  get(k,d){try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v)}catch(e){return d}},
  set(k,v){try{localStorage.setItem(k,JSON.stringify(v));return true}catch(e){return false}}
};
const hash=s=>{let x=2166136261;s=String(s);for(let i=0;i<s.length;i++){x^=s.charCodeAt(i);x=Math.imul(x,16777619)}return x>>>0};
const HOUR=3600e3,DAY=24*HOUR;
const REDUCED=window.matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches;
const ANIMS=new Set();
const regAnim=fn=>{ANIMS.add(fn);return fn};
const stopAnims=()=>{ANIMS.forEach(f=>{try{f()}catch(e){}});ANIMS.clear()};

const dayKey=ts=>{const d=new Date(ts);return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')};
const dayLabel=k=>{
  const t=dayKey(Date.now()),y=dayKey(Date.now()-DAY);
  const d=new Date(k+'T12:00:00').toLocaleDateString('en-GB',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
  return k===t?'Today, '+d:k===y?'Yesterday, '+d:d;
};
const clock=ts=>new Date(ts).toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'});
const ago=ts=>{const m=Math.round((Date.now()-ts)/60000);if(m<1)return'just now';if(m<60)return m+' min ago';const h=Math.round(m/60);if(h<24)return h+' h ago';return Math.round(h/24)+' d ago'};

/* ---------- source registry (edit these lists to change what the collector reads) ---------- */
const SRC={
  og:[
    {id:'ogj',name:'Oil & Gas Journal',url:'https://www.ogj.com'},
    {id:'ogiq',name:'Oil & Gas IQ',url:'https://www.oilandgasiq.com'},
    {id:'rigzone',name:'Rigzone',url:'https://www.rigzone.com'},
    {id:'worldoil',name:'World Oil',url:'https://www.worldoil.com'},
    {id:'offtech',name:'Offshore Technology',url:'https://www.offshore-technology.com'},
    {id:'jpt',name:'Journal of Petroleum Technology',url:'https://jpt.spe.org'},
    {id:'hart',name:'Hart Energy',url:'https://www.hartenergy.com'},
    {id:'oilprice',name:'OilPrice.com',url:'https://oilprice.com'},
    {id:'upstream',name:'Upstream',url:'https://www.upstreamonline.com'}
  ],
  ai:[
    {id:'arxiv',name:'arXiv cs.AI / cs.LG',url:'https://arxiv.org/list/cs.AI/recent'},
    {id:'anthropic',name:'Anthropic News',url:'https://www.anthropic.com/news'},
    {id:'openai',name:'OpenAI News',url:'https://openai.com/news'},
    {id:'deepmind',name:'Google DeepMind Blog',url:'https://deepmind.google'},
    {id:'hf',name:'Hugging Face Blog',url:'https://huggingface.co/blog'},
    {id:'mit',name:'MIT Technology Review',url:'https://www.technologyreview.com'},
    {id:'batch',name:'The Batch',url:'https://www.deeplearning.ai/the-batch/'},
    {id:'msr',name:'Microsoft Research Blog',url:'https://www.microsoft.com/en-us/research/blog/'},
    {id:'arxivenergy',name:'arXiv (AI + energy)',url:'https://arxiv.org'}
  ]
};
/* Competitor watchlist for Honeywell in oil, gas and energy automation. Edit to match your own definition. */
const COMPANIES=[
  {id:'emerson',name:'Emerson',url:'https://www.emerson.com',area:'Process automation and control'},
  {id:'yokogawa',name:'Yokogawa',url:'https://www.yokogawa.com',area:'Process automation and control'},
  {id:'abb',name:'ABB',url:'https://new.abb.com',area:'Automation, electrification, digital'},
  {id:'siemens',name:'Siemens',url:'https://www.siemens.com',area:'Automation and industrial software'},
  {id:'schneider',name:'Schneider Electric / AVEVA',url:'https://www.se.com',area:'Automation, industrial software'},
  {id:'rockwell',name:'Rockwell Automation',url:'https://www.rockwellautomation.com',area:'Control systems and software'},
  {id:'bakerhughes',name:'Baker Hughes',url:'https://www.bakerhughes.com',area:'Energy technology and digital'},
  {id:'slb',name:'SLB',url:'https://www.slb.com',area:'Oilfield services and digital'},
  {id:'halliburton',name:'Halliburton',url:'https://www.halliburton.com',area:'Oilfield services and digital'}
];
const REGIONS=['North America','Europe','China','India','Middle East','Global'];
const TOPICS={
  og:['Drilling automation','Production optimization','Offshore projects','Digital twins','Methane and emissions','Well integrity','Subsea systems','Artificial lift','Market and prices','Regulation and policy','Unconventional wells','Gas processing'],
  comp:['Product launch','Partnership','Contract award','Acquisition','Software release','Field deployment','Sustainability programme'],
  ai:['New model release','Agentic AI in industry','Research paper','Open-source tool','AI safety and policy','Time-series forecasting','Explainable AI','Physics-informed ML','AI chips and compute','Enterprise adoption']
};
const SMAP={};[...SRC.og,...SRC.ai].forEach(s=>SMAP[s.id]=s);
const CMAP={};COMPANIES.forEach(c=>CMAP[c.id]=c);
const FEEDS={og:'Oil & gas news',comp:'Competitor news',ai:'AI news'};

/* ---------- feed engine ---------- */
/* Set LIVE_API to the URL of your collector service to switch from demo data to real headlines.
   Expected response: JSON array of {id, feed:'og'|'comp'|'ai', src, srcName, company, region, title, summary, url, pubAt(ms), topic}. */
const LIVE_API='';
let FS=store.get('wh.feeds.v1',{items:{},last:0});
if(!FS||!FS.items)FS={items:{},last:0};
const feedListeners=new Set();

function makeDemo(feed,id,pubAt){
  const hv=hash(id),outlets=SRC[feed==='comp'?'og':feed];
  return{id,feed,src:outlets[hv%outlets.length].id,
    company:feed==='comp'?COMPANIES[(hv>>>5)%COMPANIES.length].id:null,
    region:feed==='ai'?REGIONS[(hv>>>9)%REGIONS.length]:null,
    industryRelevant:feed==='ai'?((hv>>>25)%4===0):null,
    topic:(hv>>>13)%TOPICS[feed].length,tpl:(hv>>>17)%3,pubAt,demo:true};
}
function demoTitle(it){
  const t=TOPICS[it.feed][it.topic];
  if(it.feed==='comp'){const c=CMAP[it.company].name;return[`${c}: ${t.toLowerCase()} item`,`${t} from ${c}`,`${c} \u2014 ${t.toLowerCase()}`][it.tpl]}
  return[`${t}: what the latest reports show`,`${t} draws attention this week`,`${t} \u2014 summary of recent developments`][it.tpl];
}
function itemTitle(it){return it.title||demoTitle(it)}
function itemSrcName(it){return(SMAP[it.src]||{name:it.srcName||it.src||'Unknown source'}).name}
function itemSrcUrl(it){return it.url||(SMAP[it.src]||{}).url||'#'}
function itemTag(it){return it.topicName||TOPICS[it.feed][it.topic]||''}
function itemSummary(it){return it.summary||`Placeholder summary. Live mode shows the article excerpt published by ${itemSrcName(it)}.`}

function runHour(hourKey,now){
  let added=0;
  ['og','comp','ai'].forEach(feed=>{
    const n=1+hash(feed+hourKey)%2;
    for(let i=0;i<n;i++){
      const id=`h-${feed}-${hourKey}-${i}`;if(FS.items[id])continue;
      let p=hourKey*HOUR+hash(id)%HOUR;if(p>now)p=now-i*60000;
      FS.items[id]=makeDemo(feed,id,p);added++;
    }
  });
  return added;
}
function saveFS(){
  const arr=Object.values(FS.items);
  if(arr.length>4000){arr.sort((a,b)=>a.pubAt-b.pubAt);arr.slice(0,arr.length-4000).forEach(i=>delete FS.items[i.id])}
  store.set('wh.feeds.v1',FS);
}
async function refreshFeeds(manual){
  const now=Date.now();let added=0,error=null;
  if(LIVE_API){
    try{
      const r=await fetch(LIVE_API);const arr=await r.json();
      arr.forEach(it=>{if(it&&it.id&&!FS.items[it.id]){FS.items[it.id]=Object.assign({live:true},it);added++}});
    }catch(e){error='Could not reach the feed service'}
  }else{
    if(!FS.last){
      for(let d=0;d<7;d++)['og','comp','ai'].forEach(feed=>{
        const n=6+hash(feed+d)%5;
        for(let i=0;i<n;i++){const id=`s-${feed}-${d}-${i}`;FS.items[id]=makeDemo(feed,id,now-d*DAY-hash(id)%(20*HOUR)-300000);added++}
      });
    }
    if(manual)['og','comp','ai'].forEach(feed=>{const id=`m-${feed}-${Math.floor(now/60000)}`;if(!FS.items[id]){FS.items[id]=makeDemo(feed,id,now);added++}});
    const cur=Math.floor(now/HOUR),last=FS.last?Math.floor(FS.last/HOUR):cur-1;
    for(let k=Math.max(last+1,cur-47);k<=cur;k++)added+=runHour(k,now);
  }
  FS.last=now;saveFS();
  feedListeners.forEach(f=>{try{f(added)}catch(e){}});
  return{added,error};
}
const itemsFor=feed=>Object.values(FS.items).filter(i=>i.feed===feed).sort((a,b)=>b.pubAt-a.pubAt);
const isDemo=()=>!LIVE_API;
