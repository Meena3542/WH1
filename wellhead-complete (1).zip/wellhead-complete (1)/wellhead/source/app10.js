/* =====================================================================
   TUTORIAL 12: Material balance basics
   ===================================================================== */
const T_MATBAL={
  id:'material-balance',title:'Material balance: weighing a reservoir like a tank',domain:'Reservoir and inflow',min:25,
  summary:'The simplest volumetric balance, and why it is far more sensitive than it looks.',
  build(){const N=2000000*1.210/(1.210-1.200);return`
  ${sec('Why this matters',LT(
    `<p>Imagine a sealed tank of liquid with a tiny pump drawing some out. Even with no gas or water coming in, the remaining liquid expands very slightly to fill the space, because nothing is perfectly incompressible. If you know exactly how much it expanded, you can work out how much liquid was in the tank to begin with.</p>`,
    `<p>Material balance treats the whole reservoir as a tank (hence "tank model"): what leaves at the surface must be balanced by expansion or influx underground. The simplest case, used here, is an undersaturated oil reservoir above the bubble point with no water influx and no gas cap, where the only "give" is the oil's own slight compressibility, captured through the change in its formation volume factor.</p>`))}
  ${sec('The formula',`
    ${LT(`<p>As pressure drops, above the bubble point, oil takes up slightly more room per barrel produced at surface. That tiny extra room, multiplied out, tells you how much oil must have been there in the first place.</p>`,
         `<p>Underground withdrawal (N<sub>p</sub>B<sub>o</sub>) equals the total oil-in-place expanding from B<sub>oi</sub> to B<sub>o</sub>. Solving for N gives this simple form. It applies strictly above the bubble point, with no aquifer and no free gas cap.</p>`)}
    <div class="formula">N = N<sub>p</sub> B<sub>o</sub> / (B<sub>o</sub> &minus; B<sub>oi</sub>)</div>
    <dl class="vars"><dt>N</dt><dd>original oil in place, STB</dd><dt>N<sub>p</sub></dt><dd>cumulative oil produced so far, STB</dd><dt>B<sub>oi</sub></dt><dd>oil formation volume factor at initial pressure, rb/STB</dd><dt>B<sub>o</sub></dt><dd>oil formation volume factor at current pressure, rb/STB (B<sub>o</sub> &gt; B<sub>oi</sub> as pressure falls, because the oil expands)</dd></dl>`)}
  ${sec('Worked example',`<div class="worked"><p><b>Problem.</b> A reservoir has produced 2,000,000 STB. B<sub>oi</sub> was 1.200 rb/STB; it is now 1.210 rb/STB. Estimate N.</p>
  <ol><li><code>B<sub>o</sub> &minus; B<sub>oi</sub> = 1.210 &minus; 1.200 = 0.010</code></li>
  <li><code>N = 2,000,000 &times; 1.210 / 0.010 = ${fmt(N)} STB</code>, about ${(N/1e6).toFixed(0)} million barrels.</li></ol>
  <p>Notice how large that number is for such a small produced volume. That is the method's known weak point: the denominator is a tiny difference between two similar numbers, so a small error in either B<sub>o</sub> value produces a huge swing in the answer.</p></div>`)}
  ${sec('Try it',`
  <div class="lab"><div class="lab-grid">
    <div>${slider('np','Cumulative production N<sub>p</sub>',100000,5000000,50000,2000000)}${slider('boi','B<sub>oi</sub> (initial)',1.05,1.40,0.001,1.200)}${slider('bo','B<sub>o</sub> (current)',1.05,1.45,0.001,1.210)}
    <div class="read">${readBox('rDiff','Bo \u2212 Boi')}${readBox('rN','Estimated N')}</div></div>
    <svg id="ch" class="chart" viewBox="0 0 560 300" role="img" aria-label="Estimated N against the Bo minus Boi difference, showing how sharply it grows as the difference shrinks"></svg>
  </div></div>
  <div class="callout">Try this: with N<sub>p</sub> fixed, move B<sub>o</sub> a thousandth of a barrel at a time toward B<sub>oi</sub>. Watch how fast the estimated N runs away. In practice this is exactly why undersaturated volumetric material balance is rarely trusted alone; engineers pair it with pressure and, once the reservoir crosses the bubble point, with a form that also accounts for released gas.</div>`)}
  ${sec('Common mistakes',`<ul><li>Using this exact equation below the bubble point, where free gas appears and the full two-phase material balance is needed instead.</li><li>Trusting a single-point B<sub>o</sub> difference without checking it against PVT lab data or a correlation.</li><li>Ignoring water influx or injection. Either one invalidates the "no support" assumption behind this simplified form.</li></ul>`)}
  ${sec('References',`<ul class="refs"><li>Schilthuis, R.J. (1936). Active oil and reservoir energy. <em>Transactions of the AIME</em>, 118(1), 33&ndash;52.</li><li>Dake, L.P. (1978). <em>Fundamentals of Reservoir Engineering</em>, ch. 3. Elsevier.</li><li>Craft, B.C. &amp; Hawkins, M.F. (1991). <em>Applied Petroleum Reservoir Engineering</em>, 2nd ed. Prentice Hall.</li></ul>`)}`},
  mount(root){
    function upd(){
      const np=+$('#np',root).value,boi=+$('#boi',root).value,bo=+$('#bo',root).value,diff=bo-boi;
      setOut(root,'npo',fmt(np)+' STB');setOut(root,'boio',boi.toFixed(3));setOut(root,'boo',bo.toFixed(3));
      const valid=diff>0.0001;
      const N=valid?np*bo/diff:Infinity;
      setOut(root,'rDiff',diff.toFixed(4));setOut(root,'rN',valid?fmt(N/1e6,2)+' MMSTB':'undefined (Bo \u2264 Boi)');
      const dmax=0.05,ymax=niceMax(np*bo/0.003/1e6);
      const a=axes({w:560,h:300,x0:0,x1:dmax,y0:0,y1:ymax,xs:dmax/5,ys:ymax/5,xl:'Bo \u2212 Boi',yl:'Estimated N (million STB)',fx:v=>v.toFixed(3)});
      const pts=[];for(let d=0.002;d<=dmax;d+=0.0005)pts.push([a.sx(d),a.sy(clamp(np*bo/d/1e6,0,ymax))]);
      let c=a.svg+`<path class="l-brand" d="${pathOf(pts)}"/>`;
      if(valid&&diff<=dmax)c+=`<line class="mk" x1="${a.sx(diff)}" x2="${a.sx(diff)}" y1="${a.sy(0)}" y2="${a.sy(clamp(N/1e6,0,ymax))}"/><circle class="dot-b" cx="${a.sx(diff)}" cy="${a.sy(clamp(N/1e6,0,ymax))}" r="6"/>`;
      $('#ch',root).innerHTML=c;
    }
    $$('input',root).forEach(i=>i.addEventListener('input',upd));
    upd();
  }
};
