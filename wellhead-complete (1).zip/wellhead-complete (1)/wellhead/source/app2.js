/* ---------- tutorial helpers ---------- */
const sec=(title,html)=>`<section class="sec"><h2>${title}</h2>${html}</section>`;
const LT=(lay,tech)=>`<div class="lay">${lay}</div><div class="tech">${tech}</div>`;
const slider=(id,label,min,max,step,val)=>`<label class="ctl"><span>${label}</span><input type="range" id="${id}" min="${min}" max="${max}" step="${step}" value="${val}"><output id="${id}o"></output></label>`;
const readBox=(id,label,val='')=>`<div><small>${label}</small><b id="${id}">${val}</b></div>`;
const pathOf=pts=>pts.map((p,i)=>(i?'L':'M')+p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' ');
function niceMax(v){const p=Math.pow(10,Math.floor(Math.log10(v))),m=v/p;return p*(m<=1?1:m<=2?2:m<=2.5?2.5:m<=5?5:10)}
function axes(o){
  const{w,h,x0,x1,y0,y1,xs,ys,xl,yl}=o,ml=o.ml||56,mr=o.mr||14,mt=o.mt||12,mb=o.mb||40;
  const fx=o.fx||(v=>fmt(v)),fy=o.fy||(v=>fmt(v));
  const sx=v=>ml+(v-x0)*(w-ml-mr)/(x1-x0),sy=v=>h-mb-(v-y0)*(h-mt-mb)/(y1-y0);
  let s='';const nx=Math.round((x1-x0)/xs),ny=Math.round((y1-y0)/ys);
  for(let i=0;i<=nx;i++){const v=x0+i*xs;s+=`<line class="gr" x1="${sx(v)}" x2="${sx(v)}" y1="${mt}" y2="${h-mb}"/><text class="tx" x="${sx(v)}" y="${h-mb+16}" text-anchor="middle">${fx(v)}</text>`}
  for(let i=0;i<=ny;i++){const v=y0+i*ys;s+=`<line class="gr" y1="${sy(v)}" y2="${sy(v)}" x1="${ml}" x2="${w-mr}"/><text class="tx" x="${ml-8}" y="${sy(v)+4}" text-anchor="end">${fy(v)}</text>`}
  s+=`<line class="ax" x1="${ml}" x2="${w-mr}" y1="${h-mb}" y2="${h-mb}"/><line class="ax" x1="${ml}" x2="${ml}" y1="${mt}" y2="${h-mb}"/>`;
  s+=`<text class="tx b" x="${(ml+w-mr)/2}" y="${h-4}" text-anchor="middle">${xl}</text>`;
  s+=`<text class="tx b" transform="translate(13 ${(mt+h-mb)/2}) rotate(-90)" text-anchor="middle">${yl}</text>`;
  return{sx,sy,svg:s,ml,mr,mt,mb,w,h};
}
function setOut(root,id,text){const el=$('#'+id,root);if(el)el.textContent=text}

/* =====================================================================
   TUTORIAL 1: Hydrostatic pressure and well anatomy
   ===================================================================== */
const T_HYDRO={
  id:'hydrostatic',title:'Hydrostatic pressure and the anatomy of a well',domain:'Well fundamentals',min:25,
  summary:'Why a column of mud holds back the reservoir, and how to calculate it.',
  build(){return`
  ${sec('Why this matters',LT(
    `<p>A well is a very deep, very narrow tube full of liquid. Dive to the bottom of a swimming pool and your ears tell you about it: the deeper you go, the more water is stacked above you, and the harder it presses. A well works the same way, only thousands of feet deeper.</p>
     <p>Drilling crews fill the hole with a heavy liquid called mud. Its push at the bottom has to be a little stronger than the push of the oil, gas or water trying to enter from the rock. Too weak, and fluids surge in when nobody wants them. Too strong, and the rock can crack.</p>`,
    `<p>Hydrostatic pressure is the first barrier in conventional drilling and the baseline for later work: bottomhole pressure (BHP), wellhead pressure (WHP), choke limits and control constraints all trace back to it. Keeping BHP above pore pressure (overbalance) prevents influx, or a <i>kick</i>. Keeping it below fracture pressure prevents lost circulation. The gap between the two is the mud-weight window.</p>`))}
  ${sec('Anatomy of a well',`
    <p>The diagram in the lab below is a cross-section. Read it from the top down:</p>
    <dl class="vars" style="grid-template-columns:auto 1fr">
      <dt style="font-style:normal">Wellhead and Xmas tree</dt><dd>The valves on top that open, throttle and shut the well. The choke you meet in tutorial 3 sits here.</dd>
      <dt style="font-style:normal">Casing</dt><dd>Steel pipe cemented into the rock. Each string is narrower and goes deeper than the one before (conductor, surface, intermediate, production).</dd>
      <dt style="font-style:normal">Tubing</dt><dd>The pipe inside the casing that carries oil and gas up to the surface.</dd>
      <dt style="font-style:normal">Packer</dt><dd>A rubber seal that closes the gap between tubing and casing, just above the reservoir.</dd>
      <dt style="font-style:normal">Perforations</dt><dd>Holes shot through the casing so reservoir fluid can flow in.</dd>
    </dl>`)}
  ${sec('The formula',`
    ${LT(`<p>Pressure at a depth is <b>how heavy the liquid is</b> times <b>how deep you are</b>, times a fixed conversion number. Twice as deep gives twice the pressure. Liquid that is 20% heavier gives 20% more pressure.</p>`,
         `<p>For a static column of incompressible fluid, <i>P</i> = <i>P</i><sub>0</sub> + &rho;<i>g</i><i>h</i>. In US oilfield units the constant 0.052 is the unit conversion: 1 ppg = 7.48 lb/ft&sup3;, and dividing by 144 in&sup2;/ft&sup2; gives 0.0519 psi per ft for each ppg, rounded to 0.052.</p>`)}
    <div class="formula">P = 0.052 &times; &rho; &times; TVD</div>
    <dl class="vars"><dt>P</dt><dd>hydrostatic pressure at depth, psi (gauge, so surface pressure is taken as zero)</dd><dt>&rho;</dt><dd>fluid density ("mud weight"), pounds per gallon (ppg)</dd><dt>TVD</dt><dd>true <em>vertical</em> depth, feet</dd><dt>G = 0.052&rho;</dt><dd>pressure gradient, psi per foot</dd></dl>
    <div class="callout">Use vertical depth, not the length of the hole. A well that snakes sideways for 5,000 ft adds hole length but no pressure.</div>`)}
  ${sec('Worked example (textbook style)',`
    <div class="worked"><p><b>Problem.</b> A well is drilled with 10.0 ppg mud to 10,000 ft TVD. Normal formation pressure is about 0.465 psi/ft. Is the well overbalanced?</p>
    <ol><li>Gradient: <code>0.052 &times; 10.0 = 0.52 psi/ft</code></li>
    <li>Mud pressure at the bottom: <code>0.52 &times; 10,000 = 5,200 psi</code></li>
    <li>Formation pressure: <code>0.465 &times; 10,000 = 4,650 psi</code></li>
    <li>Margin: <code>5,200 &minus; 4,650 = 550 psi</code>. Overbalanced, so the mud holds the formation back.</li></ol>
    <p>Fresh water (8.33 ppg) gives 0.433 psi/ft, which is why that value is quoted as a reference gradient in drilling texts.</p></div>`)}
  ${sec('Try it',`
  <div class="lab"><div class="lab-grid">
    <div><svg id="wb" class="chart" viewBox="0 0 460 560" role="img" aria-label="Well cross-section with a marker at the selected depth"></svg></div>
    <div>
      <svg id="gauge" class="chart" viewBox="0 0 200 128" style="max-width:280px" role="img" aria-label="Pressure gauge"></svg>
      ${slider('d','Depth (TVD)',0,15000,100,10000)}
      ${slider('rho','Mud weight',8.3,18,0.1,10)}
      ${slider('gf','Formation gradient',0.4,0.8,0.005,0.465)}
      <div class="btns"><button class="btn" id="play">Lower the gauge</button><button class="btn ghost" id="ex">Load textbook example</button></div>
      <div id="stat" style="margin:8px 0"></div>
      <div class="read">${readBox('rG','Mud gradient')}${readBox('rPm','Mud pressure')}${readBox('rPf','Formation pressure')}${readBox('rMg','Margin')}</div>
    </div></div>
    <svg id="pd" class="chart" viewBox="0 0 640 280" role="img" aria-label="Pressure against depth for mud and formation"></svg>
    <div class="worked" id="live"></div>
  </div>`)}
  ${sec('Common mistakes',`<ul><li>Using measured depth in a deviated well. Pressure follows vertical depth only.</li><li>Mixing units. The 0.052 constant works only for ppg and feet. For kg/m&sup3; and metres use <i>P</i> = &rho;<i>gh</i> directly.</li><li>Forgetting that mud density changes with temperature and pressure in deep, hot wells. The formula assumes a constant density.</li></ul>`)}
  ${sec('References',`<ul class="refs"><li>Bourgoyne, Millheim, Chenevert &amp; Young, <em>Applied Drilling Engineering</em>, SPE Textbook Series Vol. 2 (1986): hydrostatic pressure and the mud-weight window.</li><li>Numbers above are worked by hand for teaching. Check them against the chapter examples before using them in a design.</li></ul>`)}`},
  mount(root){
    const YT=70,YB=520,yd=d=>YT+d/15000*(YB-YT);
    const bands=[0,3000,6500,10000,13500,15000];
    let s='';
    for(let i=0;i<5;i++)s+=`<rect class="strata s${i}" x="0" y="${yd(bands[i])}" width="460" height="${yd(bands[i+1])-yd(bands[i])}"/>`;
    s+=`<rect class="res" x="0" y="${yd(13500)}" width="460" height="${yd(15000)-yd(13500)}"/>`;
    s+=`<rect x="0" y="${YT-4}" width="460" height="4" class="solid"/>`;
    s+=`<rect id="fluid" x="197" y="${YT}" width="46" height="0" fill="var(--brand)" fill-opacity=".4"/>`;
    s+=`<path class="cas" d="M184 ${YT}V${yd(3000)}M256 ${YT}V${yd(3000)}"/><path class="cas" d="M194 ${YT}V${yd(13500)}M246 ${YT}V${yd(13500)}"/><path class="cas t" d="M209 ${YT}V${yd(13100)}M231 ${YT}V${yd(13100)}"/>`;
    s+=`<rect class="solid" x="203" y="${yd(13100)}" width="34" height="8"/>`;
    for(let d=13600;d<=14800;d+=300)s+=`<path class="cas t" d="M194 ${yd(d)}H176M246 ${yd(d)}H264"/>`;
    s+=`<g class="solid"><rect x="210" y="${YT-34}" width="20" height="34"/><rect x="196" y="${YT-24}" width="48" height="7"/></g>`;
    for(let d=0;d<=15000;d+=3000)s+=`<text class="tx" x="6" y="${yd(d)+4}">${fmt(d)} ft</text>`;
    const lab=(y,t)=>`<text class="tx b" x="290" y="${y}">${t}</text>`;
    s+=lab(YT-14,'Wellhead and Xmas tree')+lab(yd(1500),'Surface casing')+lab(yd(7000),'Production casing')+lab(yd(9500),'Tubing')+lab(yd(13100)+6,'Packer')+lab(yd(14200),'Reservoir and perforations');
    s+=`<g id="mk"><line class="mk" x1="130" x2="330" y1="0" y2="0"/><circle class="mkdot" cx="220" cy="0" r="6"/></g>`;
    $('#wb',root).innerHTML=s;
    let g=`<path d="M20 108A80 80 0 0 1 180 108" fill="none" stroke="var(--rule)" stroke-width="12"/>`;
    for(let i=0;i<=5;i++){const a=(-90+i*36)*Math.PI/180;g+=`<text class="tx" x="${100+92*Math.sin(a)}" y="${108-92*Math.cos(a)+4}" text-anchor="middle" style="font-size:10px">${i*3}k</text>`}
    g+=`<line id="needle" x1="100" y1="108" x2="100" y2="40" stroke="var(--red)" stroke-width="3" stroke-linecap="round"/><circle cx="100" cy="108" r="6" fill="var(--ink)"/><text id="gt" class="tx b" x="100" y="126" text-anchor="middle" style="font-size:13px"></text>`;
    $('#gauge',root).innerHTML=g;

    function upd(){
      const d=+$('#d',root).value,rho=+$('#rho',root).value,gf=+$('#gf',root).value;
      setOut(root,'do',fmt(d)+' ft');setOut(root,'rhoo',rho.toFixed(1)+' ppg');setOut(root,'gfo',gf.toFixed(3)+' psi/ft');
      const G=0.052*rho,Pm=G*d,Pf=gf*d,mg=Pm-Pf;
      $('#mk',root).setAttribute('transform',`translate(0 ${yd(d)})`);
      const fl=$('#fluid',root);fl.setAttribute('height',Math.max(0,yd(d)-YT));fl.setAttribute('fill-opacity',(.2+(rho-8)/10*.5).toFixed(2));
      $('#needle',root).setAttribute('transform',`rotate(${-90+clamp(Pm/15000,0,1)*180} 100 108)`);
      setOut(root,'gt',fmt(Pm)+' psi');
      setOut(root,'rG',G.toFixed(3)+' psi/ft');setOut(root,'rPm',fmt(Pm)+' psi');setOut(root,'rPf',fmt(Pf)+' psi');setOut(root,'rMg',(mg>=0?'+':'\u2212')+fmt(Math.abs(mg))+' psi');
      const st=$('#stat',root);
      if(d===0)st.innerHTML='<span class="pill warn">At surface both pressures are zero</span>';
      else if(mg>0.5)st.innerHTML=`<span class="pill ok">Overbalanced by ${fmt(mg)} psi: the mud holds the formation back</span>`;
      else if(mg<-0.5)st.innerHTML=`<span class="pill bad">Underbalanced by ${fmt(-mg)} psi: formation fluid can flow in (kick risk)</span>`;
      else st.innerHTML='<span class="pill warn">Balanced: no margin</span>';
      const a=axes({w:640,h:280,x0:0,x1:15000,y0:15000,y1:0,xs:3000,ys:-3000,xl:'Pressure (psi)',yl:'Depth (ft)'});
      const pm=(x)=>0.052*rho*x,pf=(x)=>gf*x;
      let c=a.svg;
      c+=`<path class="${mg>=0?'ok-fill':'bad-fill'}" d="M${a.sx(0)} ${a.sy(0)}L${a.sx(pm(15000))} ${a.sy(15000)}L${a.sx(pf(15000))} ${a.sy(15000)}Z"/>`;
      c+=`<path class="l-brand" d="M${a.sx(0)} ${a.sy(0)}L${a.sx(pm(15000))} ${a.sy(15000)}"/><path class="l-amber" d="M${a.sx(0)} ${a.sy(0)}L${a.sx(pf(15000))} ${a.sy(15000)}"/>`;
      c+=`<line class="mk" x1="${a.ml}" x2="${a.w-a.mr}" y1="${a.sy(d)}" y2="${a.sy(d)}"/><circle class="dot-b" cx="${a.sx(pm(d))}" cy="${a.sy(d)}" r="6"/><circle class="dot-a" cx="${a.sx(pf(d))}" cy="${a.sy(d)}" r="6"/>`;
      c+=`<text class="tx b" x="${a.sx(pm(15000))-6}" y="${a.sy(15000)-8}" text-anchor="end" fill="var(--brand)" style="fill:var(--brand)">Mud</text><text class="tx b" x="${a.sx(pf(15000))+6}" y="${a.sy(15000)-8}" style="fill:var(--amber)">Formation</text>`;
      $('#pd',root).innerHTML=c;
      $('#live',root).innerHTML=`<p><b>Your numbers, step by step</b></p><ol><li>Gradient: <code>0.052 &times; ${rho.toFixed(1)} = ${G.toFixed(3)} psi/ft</code></li><li>Mud pressure: <code>${G.toFixed(3)} &times; ${fmt(d)} = ${fmt(Pm)} psi</code></li><li>Formation pressure: <code>${gf.toFixed(3)} &times; ${fmt(d)} = ${fmt(Pf)} psi</code></li><li>Margin: <code>${fmt(Pm)} &minus; ${fmt(Pf)} = ${fmt(mg)} psi</code></li></ol>`;
    }
    $$('input[type=range]',root).forEach(i=>i.addEventListener('input',upd));
    $('#ex',root).addEventListener('click',()=>{$('#d',root).value=10000;$('#rho',root).value=10;$('#gf',root).value=0.465;upd()});
    let stop=null;
    $('#play',root).addEventListener('click',()=>{
      if(stop){stop();return}
      let raf,t0=null;const dur=6000;$('#play',root).textContent='Stop';
      const step=t=>{if(t0==null)t0=t;const k=clamp((t-t0)/dur,0,1);$('#d',root).value=Math.round(k*150)*100;upd();if(k<1)raf=requestAnimationFrame(step);else fin()};
      const fin=()=>{cancelAnimationFrame(raf);stop=null;const b=$('#play',root);if(b)b.textContent='Lower the gauge'};
      stop=regAnim(()=>{cancelAnimationFrame(raf);stop=null});
      const s0=stop;stop=()=>{s0();fin()};
      raf=requestAnimationFrame(step);
    });
    upd();
  }
};

/* =====================================================================
   TUTORIAL 2: Inflow performance (PI and Vogel)
   ===================================================================== */
const T_IPR={
  id:'ipr-vogel',title:'Inflow performance: how much oil the reservoir gives',domain:'Reservoir and inflow',min:30,
  summary:'From a straight-line productivity index to Vogel\u2019s curve, with one well test.',
  build(){return`
  ${sec('Why this matters',LT(
    `<p>Squeeze a sponge gently and a little water comes out. Squeeze harder and more comes out. A well is similar: the lower the pressure we hold at the bottom of the well, the more oil the rock releases.</p>
     <p>There is a catch. When oil has gas dissolved in it, pulling harder makes gas bubbles form in the rock, and the bubbles get in the way. Each extra bit of pull then gives less extra oil. So the relationship is a curve that bends over, not a straight line.</p>`,
    `<p>The inflow performance relationship (IPR) gives flow rate <i>q</i> against flowing bottomhole pressure <i>P</i><sub>wf</sub> at a fixed average reservoir pressure <i>P</i><sub>r</sub>. It is the reservoir half of nodal analysis. The tubing and choke half is the outflow (VLP) curve, and their intersection is the operating point. Below the bubble point, gas evolution reduces oil relative permeability near the wellbore and the IPR curves.</p>`))}
  ${sec('Formula 1: the straight line (productivity index)',`
    ${LT(`<p>If nothing but liquid is flowing, flow is proportional to the pull. Double the pull, double the oil. The slope is called the productivity index, a single number that says how "easy" the well is.</p>`,
         `<p>Single-phase radial flow at pseudo-steady state (Darcy): <i>q</i> = 0.00708 <i>k h</i> (<i>P</i><sub>r</sub> &minus; <i>P</i><sub>wf</sub>) / [&mu; <i>B</i> (ln(<i>r</i><sub>e</sub>/<i>r</i><sub>w</sub>) &minus; 0.75 + <i>s</i>)] in field units. Everything except the pressure drop is lumped into <i>J</i>. Valid while <i>P</i><sub>wf</sub> stays above the bubble point.</p>`)}
    <div class="formula">q = J &times; (P<sub>r</sub> &minus; P<sub>wf</sub>)</div>
    <dl class="vars"><dt>q</dt><dd>oil rate, stock-tank barrels per day (STB/d)</dd><dt>J</dt><dd>productivity index, STB/d per psi</dd><dt>P<sub>r</sub></dt><dd>average reservoir pressure, psi</dd><dt>P<sub>wf</sub></dt><dd>flowing bottomhole pressure, psi</dd></dl>`)}
  ${sec('Formula 2: Vogel\u2019s curve',`
    ${LT(`<p>Vogel took many computer simulations of oil wells with dissolved gas and found one curve that fits them all. You measure the flow at one pressure, and the curve draws the rest for you.</p>`,
         `<p>Vogel (1968) fitted a dimensionless IPR to reservoir simulations of solution-gas-drive reservoirs. With <i>x</i> = <i>P</i><sub>wf</sub>/<i>P</i><sub>r</sub> the rate ratio is quadratic in <i>x</i>. It applies to saturated reservoirs (<i>P</i><sub>r</sub> at or below the bubble point). For <i>P</i><sub>r</sub> above bubble point the usual approach is a composite: linear above the bubble point, Vogel below it.</p>`)}
    <div class="formula">q / q<sub>max</sub> = 1 &minus; 0.2 (P<sub>wf</sub>/P<sub>r</sub>) &minus; 0.8 (P<sub>wf</sub>/P<sub>r</sub>)&sup2;</div>
    <dl class="vars"><dt>q<sub>max</sub></dt><dd>the rate if bottomhole pressure were dropped to zero (a reference number, not a real target)</dd></dl>`)}
  ${sec('Worked example',`
    <div class="worked"><p><b>Problem.</b> Average reservoir pressure is 2,500 psi. A well test measured 400 STB/d at P<sub>wf</sub> = 1,800 psi. What rate can we expect at 1,000 psi?</p>
    <ol><li>Ratio at the test: <code>x = 1,800 / 2,500 = 0.72</code></li>
    <li>Bracket: <code>1 &minus; 0.2(0.72) &minus; 0.8(0.72)&sup2; = 1 &minus; 0.144 &minus; 0.4147 = 0.4413</code></li>
    <li>Maximum rate: <code>q<sub>max</sub> = 400 / 0.4413 = 906 STB/d</code></li>
    <li>At 1,000 psi: <code>x = 0.40</code>, bracket <code>= 1 &minus; 0.08 &minus; 0.128 = 0.792</code>, so <code>q = 906 &times; 0.792 = 718 STB/d</code></li></ol>
    <p>A straight-line model through the same test point would give <code>J = 400/700 = 0.571</code> and a "maximum" of 1,429 STB/d. It overpredicts because it ignores the gas effect.</p></div>`)}
  ${sec('Try it',`
  <div class="lab"><div class="lab-grid">
    <div><svg id="ipr" class="chart" viewBox="0 0 560 380" role="img" aria-label="Inflow performance curves: Vogel and straight line"></svg></div>
    <div>
      ${slider('pr','Reservoir pressure',1000,5000,50,2500)}
      ${slider('pt','Test bottomhole P',300,4900,50,1800)}
      ${slider('qt','Test rate',50,2000,10,400)}
      ${slider('po','Operating bottomhole P',0,5000,10,1000)}
      <div class="btns"><button class="btn" id="play">Sweep pressure down</button><button class="btn ghost" id="rst">Reset to the worked example</button></div>
      <div class="read">${readBox('rQm','Vogel q max')}${readBox('rQo','Rate at operating P')}${readBox('rQl','Straight-line q max')}${readBox('rJ','J from the test')}</div>
    </div></div>
    <div class="worked" id="live"></div>
  </div>
  <div class="callout">Try this: raise the test rate while keeping the same test pressure. Both curves scale up, but the gap between the dashed line and the curve stays proportionally the same. Now move the test pressure closer to the reservoir pressure and watch the straight-line estimate run away.</div>`)}
  ${sec('Common mistakes',`<ul><li>Applying Vogel above the bubble point, where the well is not yet producing free gas.</li><li>Using a test taken before the well stabilised. Use stabilised rate and pressure.</li><li>Treating q<sub>max</sub> as achievable. It is a curve-fit anchor, not an operating target.</li></ul>`)}
  ${sec('References',`<ul class="refs"><li>Vogel, J.V. (1968). Inflow performance relationships for solution-gas drive wells. <em>Journal of Petroleum Technology</em>, 20(1), 83&ndash;92.</li><li>Beggs, H.D. (2003). <em>Production Optimization Using NODAL Analysis</em>. OGCI.</li><li>Dake, L.P. (1978). <em>Fundamentals of Reservoir Engineering</em>. Elsevier: radial flow and the productivity index.</li></ul>`)}`},
  mount(root){
    const W=560,H=380;
    function upd(){
      const pr=+$('#pr',root).value;
      const pt=$('#pt',root);pt.max=pr-100;if(+pt.value>pr-100)pt.value=pr-100;
      const po=$('#po',root);po.max=pr;if(+po.value>pr)po.value=pr;
      const ptv=+pt.value,qt=+$('#qt',root).value,pov=+po.value;
      setOut(root,'pro',fmt(pr)+' psi');setOut(root,'pto',fmt(ptv)+' psi');setOut(root,'qto',fmt(qt)+' STB/d');setOut(root,'poo',fmt(pov)+' psi');
      const br=x=>1-0.2*x-0.8*x*x;
      const xt=ptv/pr,qmax=qt/br(xt),J=qt/(pr-ptv),qlin=J*pr;
      const vog=p=>qmax*br(p/pr),lin=p=>J*(pr-p);
      const qo=vog(pov);
      const xmax=niceMax(Math.max(qlin,qmax)*1.05),ystep=pr>2500?1000:500,ymax=Math.ceil(pr/ystep)*ystep;
      const a=axes({w:W,h:H,x0:0,x1:xmax,y0:0,y1:ymax,xs:xmax/5,ys:ystep,xl:'Oil rate q (STB/d)',yl:'Bottomhole pressure (psi)'});
      const pts=[];for(let i=0;i<=60;i++){const p=pr*(1-i/60);pts.push([a.sx(vog(p)),a.sy(p)])}
      let c=a.svg+`<path class="l-amber" d="M${a.sx(0)} ${a.sy(pr)}L${a.sx(qlin)} ${a.sy(0)}"/><path class="l-brand" d="${pathOf(pts)}"/>`;
      c+=`<circle class="dot-a" cx="${a.sx(qt)}" cy="${a.sy(ptv)}" r="7"/><text class="tx b" x="${a.sx(qt)+10}" y="${a.sy(ptv)-8}">test point</text>`;
      c+=`<line class="mk" x1="${a.ml}" x2="${a.sx(qo)}" y1="${a.sy(pov)}" y2="${a.sy(pov)}"/><line class="mk" x1="${a.sx(qo)}" x2="${a.sx(qo)}" y1="${a.sy(pov)}" y2="${a.sy(0)}"/><circle class="dot-b" cx="${a.sx(qo)}" cy="${a.sy(pov)}" r="7"/>`;
      c+=`<text class="tx b" x="${a.w-a.mr-4}" y="${a.mt+14}" text-anchor="end" style="fill:var(--brand)">Vogel curve</text><text class="tx b" x="${a.w-a.mr-4}" y="${a.mt+30}" text-anchor="end" style="fill:var(--amber)">Straight line (PI)</text>`;
      $('#ipr',root).innerHTML=c;
      setOut(root,'rQm',fmt(qmax)+' STB/d');setOut(root,'rQo',fmt(qo)+' STB/d');setOut(root,'rQl',fmt(qlin)+' STB/d');setOut(root,'rJ',J.toFixed(3));
      const xo=pov/pr;
      $('#live',root).innerHTML=`<p><b>Your numbers, step by step</b></p><ol>
      <li>Test ratio: <code>x = ${fmt(ptv)} / ${fmt(pr)} = ${xt.toFixed(3)}</code></li>
      <li>Bracket: <code>1 &minus; 0.2(${xt.toFixed(3)}) &minus; 0.8(${xt.toFixed(3)})&sup2; = ${br(xt).toFixed(4)}</code></li>
      <li>Maximum rate: <code>q<sub>max</sub> = ${fmt(qt)} / ${br(xt).toFixed(4)} = ${fmt(qmax)} STB/d</code></li>
      <li>At P<sub>wf</sub> = ${fmt(pov)} psi: <code>x = ${xo.toFixed(3)}</code>, bracket <code>${br(xo).toFixed(4)}</code>, so <code>q = ${fmt(qo)} STB/d</code></li>
      <li>Straight line from the same test: <code>J = ${fmt(qt)} / ${fmt(pr-ptv)} = ${J.toFixed(3)}</code> and it would claim <code>${fmt(qlin)} STB/d</code> at zero pressure, which is ${fmt((qlin/qmax-1)*100)}% above Vogel.</li></ol>`;
    }
    $$('input[type=range]',root).forEach(i=>i.addEventListener('input',upd));
    $('#rst',root).addEventListener('click',()=>{$('#pr',root).value=2500;$('#pt',root).value=1800;$('#qt',root).value=400;$('#po',root).value=1000;upd()});
    let stop=null;
    $('#play',root).addEventListener('click',()=>{
      if(stop){stop();return}
      const b=$('#play',root);b.textContent='Stop';let raf,t0=null;const dur=5000;
      const fin=()=>{cancelAnimationFrame(raf);stop=null;b.textContent='Sweep pressure down'};
      const step=t=>{if(t0==null)t0=t;const k=clamp((t-t0)/dur,0,1);$('#po',root).value=Math.round(+$('#pr',root).value*(1-k)/10)*10;upd();if(k<1)raf=requestAnimationFrame(step);else fin()};
      stop=regAnim(fin);raf=requestAnimationFrame(step);
    });
    upd();
  }
};
