/* =====================================================================
   TUTORIAL 3: Choke performance (Gilbert and friends)
   ===================================================================== */
const CORR={
  gilbert:{name:'Gilbert (1954)',C:10.0,m:0.546,n:1.89},
  ros:{name:'Ros',C:17.40,m:0.5,n:2.0},
  baxendell:{name:'Baxendell',C:9.56,m:0.546,n:1.93},
  achong:{name:'Achong',C:3.82,m:0.65,n:1.88}
};
const chokeQ=(c,P,S,R)=>P*Math.pow(S,c.n)/(c.C*Math.pow(R,c.m));
const chokeP=(c,q,S,R)=>c.C*Math.pow(R,c.m)*q/Math.pow(S,c.n);

const T_CHOKE={
  id:'choke-gilbert',title:'Choke performance: how a wellhead choke sets the flow',domain:'Production engineering',min:35,
  summary:'Critical flow, the Gilbert correlation, and what changes when you open or close the choke.',
  build(){
    const g=CORR.gilbert,ex=chokeP(g,1000,24,800),s24=Math.pow(24,g.n),r800=Math.pow(800,g.m);
    return`
  ${sec('Why this matters',LT(
    `<p>The choke is a deliberately narrow spot at the wellhead, like putting your thumb over the end of a garden hose. It lets operators decide how fast the well flows and protects the equipment downstream. Squeeze it tighter and the pressure behind it rises while the flow slows. Open it up and the flow rises while the pressure behind it falls.</p>`,
    `<p>Most producing wells run their choke in <em>critical</em> (sonic) flow. There the rate depends on upstream pressure, choke size and fluid properties, and not on downstream pressure. That makes the choke a stable, predictable rate-setting device, and a natural actuator for optimisation and control. In control language the choke opening is a manipulated variable (MV), and wellhead pressure and rate are controlled variables (CV).</p>`))}
  ${sec('Critical flow, explained',`
    ${LT(`<p>Squeezing through a narrow gap, the oil-and-gas mix speeds up until it hits the speed of sound in that mix. After that, pressure changes <em>downstream</em> cannot travel back <em>upstream</em>. It is like a bottleneck on a road: the bottleneck decides how many cars get through, however empty the road is beyond it.</p>`,
         `<p>Flow is critical when the ratio of downstream to upstream pressure falls below a critical value. For gas&ndash;liquid mixtures a working rule is <i>P</i><sub>d</sub>/<i>P</i><sub>u</sub> &lt; 0.55. For an ideal gas the exact value is (2/(<i>k</i>+1))<sup>k/(k&minus;1)</sup>, which is 0.528 for <i>k</i> = 1.4. Above the critical ratio the flow is subcritical and depends on the pressure drop, so the correlations below do not apply.</p>`)}`)}
  ${sec('The formula',`
    ${LT(`<p>Gilbert measured many real wells and found that the pressure at the wellhead grows with the flow rate and with how much gas comes with the oil, and shrinks fast when the choke is bigger. His pattern fits one short equation.</p>`,
         `<p>Gilbert (1954) is an empirical power-law fit for critical flow. The same functional form, with different constants, was fitted by Ros, Baxendell and Achong. Rearranged for rate: <i>q</i> = <i>P</i><sub>wh</sub> <i>S</i><sup>1.89</sup> / (10 <i>R</i><sup>0.546</sup>).</p>`)}
    <div class="formula">P<sub>wh</sub> = 10.0 &times; R<sup>0.546</sup> &times; q / S<sup>1.89</sup></div>
    <dl class="vars"><dt>P<sub>wh</sub></dt><dd>upstream (wellhead) pressure, psig</dd><dt>R</dt><dd>gas&ndash;liquid ratio, scf per stock-tank barrel</dd><dt>q</dt><dd>liquid rate, STB/d</dd><dt>S</dt><dd>choke size in 64ths of an inch (24 means 24/64 in)</dd></dl>
    <div class="callout">Constants for the four correlations are as commonly tabulated in production-engineering texts. Check them against your reference and your unit system before using them for design.</div>`)}
  ${sec('Worked example',`
    <div class="worked"><p><b>Problem.</b> A well makes 1,000 STB/d with a gas&ndash;liquid ratio of 800 scf/STB through a 24/64 in choke. Estimate the wellhead pressure.</p>
    <ol><li>Choke term: <code>24<sup>1.89</sup> = ${fmt(s24,1)}</code></li>
    <li>Gas term: <code>800<sup>0.546</sup> = ${fmt(r800,2)}</code></li>
    <li>Pressure: <code>P<sub>wh</sub> = 10.0 &times; ${fmt(r800,2)} &times; 1,000 / ${fmt(s24,1)} = ${fmt(ex)} psig</code></li></ol>
    <p><b>Now turn it around.</b> If the pressure holds at ${fmt(ex)} psig and we open the choke to 32/64 in, the rate rises to <code>q = ${fmt(ex)} &times; 32<sup>1.89</sup> / (10 &times; ${fmt(r800,2)}) = ${fmt(chokeQ(g,ex,32,800))} STB/d</code>. A one-third larger opening gave about 1.7 times the rate, because rate goes with the choke size raised to nearly the power of two (choke <em>area</em>).</p></div>`)}
  ${sec('Try it',`
  <div class="lab"><div class="lab-grid" style="grid-template-columns:minmax(0,1fr)">
    <div><svg id="pipe" class="chart" viewBox="0 0 560 215" role="img" aria-label="Animated flow through a choke: oil droplets and gas bubbles speed up through the narrow throat"></svg>
    <div class="btns"><button class="btn" id="play">Pause flow</button><span class="pill" id="regime"></span></div></div>
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:0 24px">
      <div>
      <label class="ctl"><span>Correlation</span><select id="cor" style="grid-column:2/4">${Object.keys(CORR).map(k=>`<option value="${k}">${CORR[k].name}</option>`).join('')}</select></label>
      ${slider('S','Choke size',8,64,1,24)}
      ${slider('R','Gas&ndash;liquid ratio',200,3000,50,800)}
      ${slider('P','Wellhead pressure',200,3000,25,950)}
      ${slider('Pd','Flowline pressure',50,1500,10,300)}
      </div>
      <div><div class="read">${readBox('rQ','Predicted rate')}${readBox('rRat','Pd / Pwh')}</div><div id="live" class="worked" style="margin:0"></div></div>
    </div>
    <svg id="cq" class="chart" viewBox="0 0 640 320" role="img" aria-label="Rate against choke size for four correlations"></svg>
  </div></div>
  <div class="callout">Try this: keep pressure fixed and drag the choke from 16 to 32. Watch the droplets speed up in the throat, and check the rate on the chart. Then raise flowline pressure until the ratio passes 0.55 and the flow is no longer critical.</div>`)}
  ${sec('Common mistakes',`<ul><li>Using a critical-flow correlation when the flow is subcritical (ratio above about 0.55). The result is not valid.</li><li>Mixing units. Gas&ndash;liquid ratio in Mscf/STB needs a different constant (Gilbert uses 435 there).</li><li>Treating an empirical fit as a physical law. Calibrate against your own well tests.</li></ul>`)}
  ${sec('References',`<ul class="refs"><li>Gilbert, W.E. (1954). Flowing and gas-lift well performance. <em>API Drilling and Production Practice</em>, 126&ndash;157.</li><li>Brill, J.P. &amp; Mukherjee, H. (1999). <em>Multiphase Flow in Wells</em>. SPE Monograph Vol. 17.</li><li>Economides, Hill, Ehlig-Economides &amp; Zhu (2013). <em>Petroleum Production Systems</em>, 2nd ed. Prentice Hall.</li></ul>`)}`},
  mount(root){
    const H=90,CY=100,svg=$('#pipe',root),NP=46;
    let s=`<rect class="pipe" x="20" y="${CY-H/2}" width="520" height="${H}"/><polygon id="wt" class="wedge"/><polygon id="wb" class="wedge"/>`;
    s+=`<g id="parts">${Array.from({length:NP},()=>'<circle r="3"/>').join('')}</g>`;
    s+=`<text class="tx b" x="24" y="34" id="lp"></text><text class="tx b" x="536" y="34" id="rp" text-anchor="end"></text><text class="tx b" x="280" y="200" id="lc" text-anchor="middle"></text>`;
    s+=`<text class="tx" x="24" y="200">flow &rarr;</text>`;
    svg.innerHTML=s;
    const circles=$$('#parts circle',root);
    const parts=Array.from({length:NP},(_,i)=>({x:20+(i/NP)*520,lane:((hash('l'+i)%180)/100)-0.9,u:(hash('u'+i)%1000)/1000}));
    const cur={q:1000,R:800,ap:50};
    const hL=x=>{const ap=cur.ap;if(x<=210||x>=350)return H;if(x<250)return H+(ap-H)*(x-210)/40;if(x<=310)return ap;return ap+(H-ap)*(x-310)/40};
    function drawParts(){
      const gs=clamp(cur.R/3500,.1,.6);
      parts.forEach((p,i)=>{const h=hL(p.x),c=circles[i];c.setAttribute('cx',p.x.toFixed(1));c.setAttribute('cy',(CY+p.lane*h/2*.85).toFixed(1));
        const gas=p.u<gs;c.setAttribute('class',gas?'gas':'oil');c.setAttribute('r',gas?3.6:3)});
    }
    let raf=null,last=0,playing=!REDUCED;
    function frame(t){
      const dt=Math.min(.05,(t-last)/1000);last=t;
      const v0=60*clamp(cur.q/1000,.12,3);
      parts.forEach(p=>{p.x+=v0*(H/hL(p.x))*dt;if(p.x>540){p.x=20;p.lane=((hash('r'+Math.floor(t)+p.u)%180)/100)-0.9}});
      drawParts();raf=requestAnimationFrame(frame);
    }
    const stopLoop=()=>{if(raf)cancelAnimationFrame(raf);raf=null};
    const startLoop=()=>{stopLoop();last=performance.now();raf=requestAnimationFrame(frame)};
    regAnim(stopLoop);
    const btn=$('#play',root);
    btn.textContent=playing?'Pause flow':'Play flow';
    btn.addEventListener('click',()=>{playing=!playing;btn.textContent=playing?'Pause flow':'Play flow';playing?startLoop():stopLoop()});

    function upd(){
      const c=CORR[$('#cor',root).value],S=+$('#S',root).value,R=+$('#R',root).value,P=+$('#P',root).value,Pd=+$('#Pd',root).value;
      setOut(root,'So',S+'/64 in');setOut(root,'Ro',fmt(R)+' scf/STB');setOut(root,'Po',fmt(P)+' psig');setOut(root,'Pdo',fmt(Pd)+' psig');
      const q=chokeQ(c,P,S,R),ratio=Pd/P,crit=ratio<0.55;
      cur.q=q;cur.R=R;cur.ap=10+S/64*74;
      const ap=cur.ap;
      $('#wt',root).setAttribute('points',`210,${CY-H/2} 250,${CY-ap/2} 310,${CY-ap/2} 350,${CY-H/2}`);
      $('#wb',root).setAttribute('points',`210,${CY+H/2} 250,${CY+ap/2} 310,${CY+ap/2} 350,${CY+H/2}`);
      setOut(root,'lp','Upstream '+fmt(P)+' psig');setOut(root,'rp','Downstream '+fmt(Pd)+' psig');setOut(root,'lc','Choke '+S+'/64 in');
      setOut(root,'rQ',fmt(q)+' STB/d');setOut(root,'rRat',ratio.toFixed(2));
      const rg=$('#regime',root);rg.className='pill '+(crit?'ok':'bad');rg.textContent=crit?'Critical flow: correlation applies':'Subcritical: correlation not valid';
      const sn=Math.pow(S,c.n),rm=Math.pow(R,c.m);
      $('#live',root).innerHTML=`<p><b>Your numbers, step by step</b></p><ol><li><code>S<sup>${c.n}</sup> = ${S}<sup>${c.n}</sup> = ${fmt(sn,1)}</code></li><li><code>R<sup>${c.m}</sup> = ${fmt(R)}<sup>${c.m}</sup> = ${fmt(rm,2)}</code></li><li><code>q = ${fmt(P)} &times; ${fmt(sn,1)} / (${c.C} &times; ${fmt(rm,2)}) = ${fmt(q)} STB/d</code></li></ol>`;
      const qs=Object.keys(CORR).map(k=>chokeQ(CORR[k],P,64,R)),ymax=niceMax(Math.max(...qs)*1.05);
      const a=axes({w:640,h:320,mr:110,x0:8,x1:64,y0:0,y1:ymax,xs:8,ys:ymax/5,xl:'Choke size (64ths of an inch)',yl:'Rate (STB/d)'});
      let ch=a.svg;
      Object.keys(CORR).forEach(k=>{
        const pts=[];for(let S2=8;S2<=64;S2+=2)pts.push([a.sx(S2),a.sy(chokeQ(CORR[k],P,S2,R))]);
        const sel=CORR[k]===c;
        ch+=`<path class="${sel?'l-brand':'l-grey'}" d="${pathOf(pts)}"/><text class="tx${sel?' b':''}" x="${a.sx(64)+6}" y="${a.sy(chokeQ(CORR[k],P,64,R))+4}" ${sel?'style="fill:var(--brand)"':''}>${CORR[k].name.replace(' (1954)','')}</text>`;
      });
      ch+=`<line class="mk" x1="${a.sx(S)}" x2="${a.sx(S)}" y1="${a.sy(0)}" y2="${a.sy(q)}"/><circle class="dot-b" cx="${a.sx(S)}" cy="${a.sy(q)}" r="7"/>`;
      $('#cq',root).innerHTML=ch;
      if(!playing||REDUCED)drawParts();
    }
    $$('input,select',root).forEach(i=>i.addEventListener('input',upd));
    upd();drawParts();
    if(playing)startLoop();
  }
};

/* =====================================================================
   TUTORIAL 4: MPC receding horizon on a choke
   ===================================================================== */
const MPC={A:0.85,B:-0.6,R:-40,T:60,QW:1};
function solveMPC(y0,uPrev,N,lam,umax,warm){
  const{A,B,R,QW}=MPC,gN=Math.abs(B)*(1-Math.pow(A,N))/(1-A),L=2*QW*gN*gN+8*lam+1e-6;
  const grad=u=>{
    const y=new Array(N+1);y[0]=y0;for(let i=0;i<N;i++)y[i+1]=A*y[i]+B*u[i];
    const gr=new Array(N);let p=0;
    for(let i=N-1;i>=0;i--){p=2*QW*(y[i+1]-R)+A*p;gr[i]=B*p}
    for(let i=0;i<N;i++){const dp=u[i]-(i?u[i-1]:uPrev),dn=i<N-1?u[i+1]-u[i]:0;gr[i]+=2*lam*(dp-dn)}
    return gr;
  };
  let u=warm.slice(0,N);while(u.length<N)u.push(u.length?u[u.length-1]:0);
  u=u.map(v=>clamp(v,-umax,umax));
  let z=u.slice(),t=1;
  for(let it=0;it<300;it++){
    const gr=grad(z),un=z.map((v,i)=>clamp(v-gr[i]/L,-umax,umax)),tn=(1+Math.sqrt(1+4*t*t))/2;
    z=un.map((v,i)=>v+(t-1)/tn*(v-u[i]));u=un;t=tn;
  }
  return u;
}
function simulateMPC(pr){
  const{A,B,T}=MPC,bp=B*(1+pr.gerr/100);
  let y=0,uPrev=0,warm=new Array(pr.N).fill(0);
  const ys=[],us=[],plans=[],preds=[];
  for(let k=0;k<T;k++){
    if(pr.dist&&k===30)y+=15;
    ys.push(y);
    const plan=solveMPC(y,uPrev,pr.N,pr.lam,pr.umax,warm);
    const pd=[y];for(let j=0;j<pr.N;j++)pd.push(A*pd[j]+B*plan[j]);
    plans.push(plan);preds.push(pd);us.push(plan[0]);
    y=A*y+bp*plan[0];uPrev=plan[0];
    warm=plan.slice(1).concat([plan[plan.length-1]]);
  }
  ys.push(y);
  return{ys,us,plans,preds};
}

const T_MPC={
  id:'mpc-receding',title:'Model predictive control: planning ahead, moving once',domain:'Instrumentation and control',min:40,
  summary:'The receding-horizon idea, shown on a choke holding wellhead pressure.',
  build(){
    const loop=`<svg class="chart" viewBox="0 0 780 150" role="img" aria-label="The MPC loop: measure, predict with a model, optimise the plan, apply only the first move, then repeat at the next sample" style="max-width:820px">
      <defs><marker id="ah" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="var(--ink2)"/></marker></defs>
      ${['1 Measure','2 Predict','3 Optimise','4 Apply move 1','5 Shift and repeat'].map((t,i)=>{const x=8+i*154;return`<rect x="${x}" y="30" width="136" height="54" fill="var(--panel)" stroke="var(--ink)" stroke-width="1.5"/><text class="tx b" x="${x+68}" y="52" text-anchor="middle" style="font-size:14px;fill:var(--ink)">${t}</text><text class="tx" x="${x+68}" y="70" text-anchor="middle">${['read wellhead P','model looks N steps ahead','best moves within limits','only the first one','wait one sample'][i]}</text>${i<4?`<line x1="${x+138}" y1="57" x2="${x+152}" y2="57" stroke="var(--ink2)" stroke-width="2" marker-end="url(#ah)"/>`:''}`}).join('')}
      <path d="M700 86V122H76V88" fill="none" stroke="var(--amber)" stroke-width="2" stroke-dasharray="6 4" marker-end="url(#ah)"/>
      <text class="tx b" x="388" y="140" text-anchor="middle" style="fill:var(--amber)">new measurement, new plan, every sample</text></svg>`;
    return`
  ${sec('Why this matters',LT(
    `<p>Think of driving on a winding road. You look ahead, picture the whole sequence of steering moves you would make, but you only commit to the first bit. Then you look again, because the road, or your guess about it, may have changed. Model predictive control (MPC) does this for a machine.</p>
     <p>Here the machine is a choke and the job is to bring wellhead pressure to a new target without slamming the valve.</p>`,
    `<p>At each sample time the controller measures the state, solves a finite-horizon optimal control problem using a process model, applies only the first optimal move, and re-solves at the next sample with the horizon shifted forward (the receding horizon). The repeated measurement gives feedback; the explicit model gives constraint handling and multivariable coordination. Nonlinear MPC (NMPC) uses a nonlinear model, typically solved with tools such as GEKKO or CasADi.</p>`))}
  ${sec('The loop',loop+`<p>${''}The dashed return arrow is the whole trick. The plan is thrown away and rebuilt every sample, so errors in the model or surprise disturbances get corrected on the next pass.</p>`)}
  ${sec('The formula',`
    ${LT(`<p>MPC scores every possible plan with a simple "cost". The cost goes up when the pressure is far from target, and it also goes up when the valve is moved in big jerks. The controller picks the cheapest plan, so it has to balance getting there quickly against being gentle.</p>`,
         `<p>The cost is a quadratic tracking term plus a move-suppression term, minimised over the input sequence subject to the model and input bounds. Larger &lambda; gives smoother, slower control. Larger <i>N</i> gives more foresight and more computation.</p>`)}
    <div class="formula">J = &Sigma;<sub>j=1..N</sub> q (&#375;<sub>k+j</sub> &minus; r)&sup2; + &lambda; &Sigma;<sub>i=0..N&minus;1</sub> (u<sub>k+i</sub> &minus; u<sub>k+i&minus;1</sub>)&sup2;</div>
    <div class="formula" style="font-size:1.2rem">&#375;<sub>j+1</sub> = a &#375;<sub>j</sub> + b u<sub>j</sub> &nbsp;&nbsp; subject to &nbsp;&nbsp; &minus;u<sub>max</sub> &le; u &le; u<sub>max</sub></div>
    <dl class="vars"><dt>y</dt><dd>wellhead pressure, as a deviation from the current value, psi</dd><dt>r</dt><dd>target for y, here &minus;40 psi</dd><dt>u</dt><dd>choke opening change, % (positive opens the choke)</dd><dt>a, b</dt><dd>model: a = 0.85 (pressure fades toward equilibrium), b = &minus;0.6 psi per % per step (opening lowers pressure). Steady-state gain is b/(1&minus;a) = &minus;4 psi per %.</dd><dt>q, &lambda;</dt><dd>weights on error and on valve movement</dd><dt>N</dt><dd>prediction horizon, in samples</dd></dl>
    <p>To lower pressure by 40 psi the choke must end up about +10% more open, because 10 &times; 4 = 40.</p>`)}
  ${sec('Worked example: first move at k = 0',`<div class="worked" id="wk"></div>`)}
  ${sec('Try it',`
  <div class="lab wide"><div class="lab-grid">
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:0 24px">
      <div>${slider('N','Horizon N',1,30,1,10)}${slider('lam','Move penalty &lambda;',0,5,0.1,0.5)}${slider('um','Choke limit &plusmn;u max',5,30,1,15)}</div>
      <div>${slider('ge','Plant gain error',-50,50,5,0)}
      <div class="ctl"><span>Disturbance</span><label style="grid-column:2/4"><input type="checkbox" id="dist"> +15 psi jump at step 30</label></div>
      ${slider('k','Time step',0,60,1,0)}</div>
    </div>
    <div class="btns"><button class="btn" id="play">Play</button><button class="btn ghost" id="stp">Step +1</button><button class="btn ghost" id="rs">Reset</button></div>
    <svg id="cy" class="chart" viewBox="0 0 680 260" role="img" aria-label="Wellhead pressure history and predicted trajectory"></svg>
    <svg id="cu" class="chart" viewBox="0 0 680 190" role="img" aria-label="Choke moves applied and planned"></svg>
    <div class="read">${readBox('m1','Total error (sum |y \u2212 r|)')}${readBox('m2','Largest single move')}${readBox('m3','Pressure at the end')}${readBox('m4','Applied this step')}</div>
  </div></div>
  <div class="callout">Try this: (1) set N = 1 and watch the first plan bang into the limit. (2) Set N = 15 and &lambda; = 2 for a gentle approach. (3) Put the gain error at &minus;40% and see that pressure never quite reaches the target: the model is wrong, so the plan is wrong. Industrial MPC adds a disturbance estimate to remove that offset. (4) Lower the choke limit to 5%: the target needs +10%, so it can never be reached.</div>`)}
  ${sec('Common mistakes',`<ul><li>A horizon shorter than the process response time. The controller only sees the near future and acts myopically.</li><li>Ignoring model error. Plans are only as good as the model. Always test in shadow mode before closing the loop.</li><li>Tuning &lambda; to hide a bad model instead of fixing the model.</li><li>This teaching model is linear. A real choke has nonlinear flow behaviour (tutorial 3), so real designs use NMPC or gain scheduling.</li></ul>`)}
  ${sec('References',`<ul class="refs"><li>Rawlings, Mayne &amp; Diehl (2017). <em>Model Predictive Control: Theory, Computation, and Design</em>, 2nd ed. Nob Hill Publishing.</li><li>Camacho &amp; Bordons (2007). <em>Model Predictive Control</em>, 2nd ed. Springer.</li><li>Beal, Hedengren et al. (2018). GEKKO Optimization Suite. <em>Processes</em>, 6(8), 106. Docs: <a href="https://gekko.readthedocs.io" target="_blank" rel="noopener">gekko.readthedocs.io</a>.</li><li>Seborg, Edgar, Mellichamp &amp; Doyle. <em>Process Dynamics and Control</em>. Wiley.</li></ul>`)}`},
  mount(root){
    const{A,B,R,T}=MPC;let sim=null,k=0,timer=null;
    const params=()=>({N:Math.max(1,Math.round(+$('#N',root).value)),lam:+$('#lam',root).value,umax:+$('#um',root).value,gerr:+$('#ge',root).value,dist:$('#dist',root).checked});
    function labels(p){setOut(root,'No',p.N+' steps');setOut(root,'lamo',p.lam.toFixed(1));setOut(root,'umo','\u00B1'+p.umax+' %');setOut(root,'geo',(p.gerr>0?'+':'')+p.gerr+' %');setOut(root,'ko','step '+k)}
    function draw(){
      const p=params();labels(p);
      const ya=axes({w:680,h:260,x0:0,x1:T,y0:-80,y1:40,xs:10,ys:20,xl:'Time step',yl:'Wellhead pressure change (psi)',mr:16});
      let c=ya.svg+`<line class="l-amber" x1="${ya.sx(0)}" x2="${ya.sx(T)}" y1="${ya.sy(R)}" y2="${ya.sy(R)}"/><text class="tx b" x="${ya.sx(T)-4}" y="${ya.sy(R)-6}" text-anchor="end" style="fill:var(--amber)">target &minus;40 psi</text>`;
      if(p.dist)c+=`<line class="mk" x1="${ya.sx(30)}" x2="${ya.sx(30)}" y1="${ya.sy(40)}" y2="${ya.sy(-80)}"/><text class="tx" x="${ya.sx(30)+4}" y="${ya.sy(36)}">disturbance</text>`;
      const hist=[];for(let i=0;i<=k;i++)hist.push([ya.sx(i),ya.sy(sim.ys[i])]);
      c+=`<path class="l-brand" d="${pathOf(hist)}"/>`;
      if(k<T){const pd=sim.preds[k],pp=[];for(let j=0;j<pd.length&&k+j<=T;j++)pp.push([ya.sx(k+j),ya.sy(pd[j])]);c+=`<path class="l-pred" d="${pathOf(pp)}"/>`;
        c+=`<rect x="${ya.sx(k)}" y="${ya.mt}" width="${Math.max(0,ya.sx(Math.min(T,k+p.N))-ya.sx(k))}" height="${ya.sy(-80)-ya.mt}" fill="var(--brand)" opacity=".07"/><text class="tx" x="${ya.sx(k)+4}" y="${ya.mt+13}">prediction horizon</text>`}
      c+=`<circle class="dot-b" cx="${ya.sx(k)}" cy="${ya.sy(sim.ys[k])}" r="6"/>`;
      $('#cy',root).innerHTML=c;
      const ua=axes({w:680,h:190,x0:0,x1:T,y0:-30,y1:30,xs:10,ys:15,xl:'Time step',yl:'Choke change (%)',mr:16,mb:38});
      const bw=(ua.sx(1)-ua.sx(0))*0.7;
      const bar=(i,u,cl)=>`<rect class="${cl}" x="${ua.sx(i)+1}" y="${ua.sy(Math.max(u,0))}" width="${bw}" height="${Math.max(1,Math.abs(ua.sy(u)-ua.sy(0)))}"/>`;
      let d=ua.svg+`<line class="l-red" x1="${ua.sx(0)}" x2="${ua.sx(T)}" y1="${ua.sy(p.umax)}" y2="${ua.sy(p.umax)}"/><line class="l-red" x1="${ua.sx(0)}" x2="${ua.sx(T)}" y1="${ua.sy(-p.umax)}" y2="${ua.sy(-p.umax)}"/>`;
      for(let i=0;i<k;i++)d+=bar(i,sim.us[i],'bar-a');
      if(k<T)sim.plans[k].forEach((u,j)=>{if(k+j<T)d+=bar(k+j,u,j===0?'bar-a':'bar-p')});
      d+=`<text class="tx" x="${ua.sx(T)-4}" y="${ua.mt+12}" text-anchor="end">solid = applied, light = planned and discarded</text>`;
      $('#cu',root).innerHTML=d;
      let iae=0,pk=0;for(let i=0;i<T;i++){iae+=Math.abs(sim.ys[i]-R);pk=Math.max(pk,Math.abs(sim.us[i]-(i?sim.us[i-1]:0)))}
      setOut(root,'m1',fmt(iae)+' psi');setOut(root,'m2',pk.toFixed(1)+' %');setOut(root,'m3',sim.ys[T].toFixed(1)+' psi');setOut(root,'m4',k<T?sim.us[k].toFixed(1)+' %':'\u2014');
    }
    function recompute(){
      const p=params();sim=simulateMPC(p);
      const u1=R/B,p0=sim.plans[0];
      $('#wk',root).innerHTML=`<p><b>Problem.</b> Pressure is at 0, the target is ${R} psi, the choke can move &plusmn;${p.umax}%. What does the controller do first?</p><ol>
        <li>Try horizon N = 1, no move penalty. Solve <code>a&middot;0 + b&middot;u = r</code>, so <code>u = ${R} / ${B} = +${u1.toFixed(1)}%</code>.</li>
        <li>That exceeds the limit, so it is clipped to <code>+${Math.min(u1,p.umax).toFixed(1)}%</code>. The valve slams to its limit and, with a wrong model, may overshoot.</li>
        <li>With your horizon N = ${p.N} and &lambda; = ${p.lam.toFixed(1)}, the plan for the next moves is <code>${p0.slice(0,5).map(v=>(v>=0?'+':'')+v.toFixed(1)).join(', ')}${p.N>5?', \u2026':''}</code> (%).</li>
        <li>Only the first, <code>${(p0[0]>=0?'+':'')+p0[0].toFixed(1)}%</code>, is applied. The rest is discarded and recomputed at the next step.</li></ol>`;
      draw();
    }
    function setK(v){k=clamp(v,0,T);$('#k',root).value=k;draw()}
    function stop(){if(timer){clearInterval(timer);timer=null}const b=$('#play',root);if(b)b.textContent='Play'}
    regAnim(stop);
    ['N','lam','um','ge','dist'].forEach(id=>$('#'+id,root).addEventListener('input',()=>{stop();recompute()}));
    $('#k',root).addEventListener('input',e=>{stop();setK(+e.target.value)});
    $('#stp',root).addEventListener('click',()=>{stop();setK(k+1)});
    $('#rs',root).addEventListener('click',()=>{stop();setK(0)});
    $('#play',root).addEventListener('click',()=>{
      if(timer){stop();return}
      if(k>=T)setK(0);
      $('#play',root).textContent='Pause';
      timer=setInterval(()=>{if(k>=T){stop();return}setK(k+1)},REDUCED?400:140);
    });
    recompute();
  }
};
