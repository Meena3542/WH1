/* ---------- AI hub data ---------- */
const TOOL_CATS=['Optimization and control','Explainability','Agents and orchestration','MLOps and evaluation','Models and platforms','Petroleum and subsurface','Research sources'];
const TOOLS=[
 ['GEKKO','Optimization and control','Open source','Python library for optimisation, dynamic simulation and MPC. Good fit for choke and process control studies.','https://gekko.readthedocs.io'],
 ['CasADi','Optimization and control','Open source','Symbolic framework for nonlinear optimisation and optimal control with automatic differentiation.','https://web.casadi.org'],
 ['do-mpc','Optimization and control','Open source','Python toolbox for robust MPC and moving-horizon estimation, built on CasADi.','https://www.do-mpc.com'],
 ['acados','Optimization and control','Open source','Fast solvers for embedded nonlinear optimal control, for real-time targets.','https://docs.acados.org'],
 ['Pyomo','Optimization and control','Open source','Algebraic modelling language for linear, nonlinear and mixed-integer optimisation.','https://www.pyomo.org'],
 ['python-control','Optimization and control','Open source','Classical control analysis: transfer functions, step responses, PID design.','https://python-control.readthedocs.io'],
 ['SHAP','Explainability','Open source','Shapley-value feature attributions for any model. Start here for explaining predictions.','https://shap.readthedocs.io'],
 ['LIME','Explainability','Open source','Local surrogate explanations for individual predictions.','https://github.com/marcotcr/lime'],
 ['Captum','Explainability','Open source','Attribution methods for PyTorch models.','https://captum.ai'],
 ['InterpretML','Explainability','Open source','Glass-box models and explanation tools in one package.','https://interpret.ml'],
 ['LangGraph','Agents and orchestration','Open source','Build stateful multi-agent workflows as graphs, with loops and human checkpoints.','https://langchain-ai.github.io/langgraph/'],
 ['AutoGen','Agents and orchestration','Open source','Framework for multi-agent conversations and tool use.','https://microsoft.github.io/autogen/'],
 ['CrewAI','Agents and orchestration','Open source','Role-based agent teams for structured tasks.','https://www.crewai.com'],
 ['LlamaIndex','Agents and orchestration','Open source','Connect language models to your documents for retrieval and question answering.','https://www.llamaindex.ai'],
 ['Model Context Protocol','Agents and orchestration','Open standard','Open standard for connecting AI assistants to tools and data sources.','https://modelcontextprotocol.io'],
 ['MLflow','MLOps and evaluation','Open source','Experiment tracking, model registry and deployment.','https://mlflow.org'],
 ['Weights & Biases','MLOps and evaluation','Commercial platform','Experiment tracking and dashboards for training runs.','https://wandb.ai'],
 ['DVC','MLOps and evaluation','Open source','Version control for datasets and pipelines alongside Git.','https://dvc.org'],
 ['Ragas','MLOps and evaluation','Open source','Metrics for evaluating retrieval-augmented generation systems.','https://docs.ragas.io'],
 ['Langfuse','MLOps and evaluation','Open source','Tracing, prompt versioning and evaluation for LLM applications.','https://langfuse.com'],
 ['Evidently','MLOps and evaluation','Open source','Data and model drift reports and monitoring.','https://www.evidentlyai.com'],
 ['Optuna','MLOps and evaluation','Open source','Hyperparameter optimisation with pruning.','https://optuna.org'],
 ['Hugging Face','Models and platforms','Platform','Model hub, datasets and libraries for open models.','https://huggingface.co'],
 ['PyTorch','Models and platforms','Open source','Deep learning framework.','https://pytorch.org'],
 ['scikit-learn','Models and platforms','Open source','Classical machine learning: regression, trees, clustering, pipelines.','https://scikit-learn.org'],
 ['Ollama','Models and platforms','Open source','Run open models locally, useful when data cannot leave your network.','https://ollama.com'],
 ['Claude API','Models and platforms','Commercial API','Anthropic\u2019s model API and documentation.','https://docs.claude.com'],
 ['OpenAI API','Models and platforms','Commercial API','OpenAI\u2019s model API and documentation.','https://platform.openai.com/docs'],
 ['Gemini API','Models and platforms','Commercial API','Google\u2019s model API and documentation.','https://ai.google.dev'],
 ['lasio','Petroleum and subsurface','Open source','Read and write well log (LAS) files in Python.','https://lasio.readthedocs.io'],
 ['OPM (Open Porous Media)','Petroleum and subsurface','Open source','Open-source reservoir simulation tools.','https://opm-project.org'],
 ['NeqSim','Petroleum and subsurface','Open source','Thermodynamic and process calculations for oil and gas, from Equinor.','https://github.com/equinor/neqsim'],
 ['OSDU Forum','Petroleum and subsurface','Open standard','Open data platform standard for subsurface and well data.','https://osduforum.org'],
 ['Equinor Volve data','Petroleum and subsurface','Open dataset','Real North Sea field dataset released for research and teaching.','https://www.equinor.com/energy/volve-data-sharing'],
 ['SPE OnePetro','Petroleum and subsurface','Publisher','Technical papers and journals from the petroleum industry.','https://onepetro.org'],
 ['arXiv','Research sources','Open access','Preprints in AI, machine learning and control.','https://arxiv.org'],
 ['Hugging Face Papers','Research sources','Open access','Daily curated AI papers with linked models and code.','https://huggingface.co/papers'],
 ['Semantic Scholar','Research sources','Free service','Search engine for research papers with citation graphs.','https://www.semanticscholar.org'],
 ['SPE','Research sources','Professional society','Society of Petroleum Engineers: events, journals, technical sections.','https://www.spe.org']
].map(a=>({name:a[0],cat:a[1],kind:a[2],desc:a[3],url:a[4]}));

const PRACTICES=[
 ['Start from the decision','Write down who acts on the output and what "better" means before choosing a model. A well-scoped question beats a clever model.'],
 ['Keep physics in the loop','Combine first-principles models with data. Check outputs against mass balance, pressure limits and physical ranges before anyone acts on them.'],
 ['Run in shadow mode first','Log recommendations next to what operators actually did. Move to advisory, then supervised control, only after the record supports it.'],
 ['Respect the IT/OT boundary','Recommendations travel through validated interfaces. Hard limits on setpoints live in the control layer, not in the AI. Follow your site\u2019s industrial security standard (for example IEC 62443).'],
 ['Evaluate honestly','Split time series by time, not at random, to avoid leakage. For language models, keep a fixed set of questions with known answers and check that answers are grounded in sources.'],
 ['Make results explainable','Show which inputs drove a prediction, or which passages an answer came from. Then test that the explanation is faithful, not just plausible.'],
 ['Version everything','Data, prompts, models and configuration all change results. Record versions and trace each output back to its inputs.'],
 ['Watch drift and cost','Monitor input drift, accuracy decay, latency and spend. Decide in advance what triggers a retrain or a rollback.'],
 ['Keep humans on high-consequence actions','Use approval gates and confidence thresholds for anything that touches safety, production or the environment.'],
 ['Protect data','Do not paste confidential well or contract data into tools you have not approved. Prefer private deployments where the data is sensitive.']
];

/* ---------- curriculum ---------- */
const CURRICULUM=[T_HYDRO,T_PVT,T_PHASE,T_MUD,T_UNITS,T_DARCY,T_IPR,T_DRIVE,T_DECLINE,T_MATBAL,T_CHOKE,T_MPC];
const TUTS={};CURRICULUM.forEach(t=>TUTS[t.id]=t);
const READY=CURRICULUM.map(t=>t.id);
const DOMAINS=[
 {name:'Well fundamentals',blurb:'The vocabulary and physics everything else stands on.',topics:[['hydrostatic','Well anatomy and hydrostatic pressure','Casing, tubing, mud weight, overbalance.'],['pvt-rs','Reservoir fluids and PVT','Formation volume factor, solution gas, bubble point.'],['phase-behavior','Phase behaviour','Black oil, volatile oil, gas condensate, dry gas.'],['mud-window','Pore pressure, fracture pressure and the mud window','Where safe drilling pressures sit.'],['units','Units that trip people up','psi, bar, ppg, API gravity, scf and Mscf.']]},
 {name:'Reservoir and inflow',blurb:'How fluids get from rock to wellbore.',topics:[['darcy-radial','Darcy\u2019s law and radial flow','Permeability, thickness, viscosity, skin.'],['ipr-vogel','Inflow performance: PI and Vogel','One well test, a whole curve.'],['drive-mechanisms','Drive mechanisms','Solution gas, gas cap and water drive.'],['decline-curves','Decline curve analysis','Arps exponential, hyperbolic and harmonic declines.'],['material-balance','Material balance basics','Tank model of a reservoir.']]},
 {name:'Drilling and completions',blurb:'Building the well and getting it ready to produce.',topics:[['','Rotary drilling, bits and BHA','What is at the end of the string.'],['','Mud hydraulics and ECD','Pump pressure, annular losses, equivalent circulating density.'],['','Well control','Kicks, shut-in, kill sheets, worked example.'],['','Casing design and cementing','Burst, collapse, tension and safety factors.'],['','Completions and perforating','Cased hole, open hole, sand control.'],['','Directional and horizontal wells','Trajectory, dogleg severity, TVD versus MD.']]},
 {name:'Production engineering',blurb:'Getting the most out of a flowing well.',topics:[['','Multiphase flow in tubing','Flow regimes and pressure loss.'],['','Nodal analysis','Inflow meets outflow: the operating point.'],['choke-gilbert','Choke performance','Critical flow and empirical correlations.'],['','Artificial lift','Gas lift, ESP and rod pump compared.'],['','Slugging and unstable flow','Why rates and pressures oscillate.'],['','Production optimisation','Allocating lift gas and choke settings across wells.']]},
 {name:'Facilities and flow assurance',blurb:'From wellhead to sales point.',topics:[['','Separation','How a separator splits oil, gas and water.'],['','Gas processing and dehydration','Removing water and heavy components.'],['','Hydrates, wax, scale and corrosion','What blocks and damages lines.'],['','Pipeline hydraulics','Multiphase transport and pressure drop.'],['','Flaring, venting and methane','Sources and how they are measured.']]},
 {name:'Well testing and logging',blurb:'Measuring what is down there.',topics:[['','Pressure build-up and drawdown tests','Reading permeability and skin from a curve.'],['','Reading well logs','Gamma ray, resistivity, density and neutron.'],['','Archie\u2019s equation','Water saturation from resistivity.'],['','Downhole gauges and production logging','Where the fluid comes from along the well.']]},
 {name:'Instrumentation and control',blurb:'Sensors, controllers and the systems that run them.',topics:[['','Sensors and meters','Pressure, temperature, flow and multiphase meters.'],['','PID control from first principles','P, I and D by example, tuning and windup.'],['mpc-receding','Model predictive control','Receding horizon on a choke.'],['','SCADA, DCS and OT layers','Where data and decisions sit.'],['','Safety instrumented systems and alarms','SIL, trips, alarm floods.'],['','Closed-loop choke control','Advisory, shadow, then supervised autonomy.']]},
 {name:'Optimisation and numerical methods',blurb:'The mathematics behind the decisions.',topics:[['','Linear and nonlinear programming','Feasible region, objective, constraints, by example.'],['','Real-time optimisation and MPC','How the two layers differ and cooperate.'],['','State and parameter estimation','Kalman filter and moving-horizon estimation.'],['','Hands-on with GEKKO','Build and solve a small well model.'],['','Surrogate models and uncertainty','Fast approximations and how wrong they can be.']]},
 {name:'AI and machine learning',blurb:'Practical AI for wells and facilities.',topics:[['','Preparing sensor time series','Gaps, outliers, and splits without leakage.'],['','Virtual flow metering','Estimating rates from pressures and temperatures.'],['','Anomaly detection and predictive maintenance','Baselines, thresholds, false alarms.'],['','Physics-informed machine learning','Putting equations inside the model.'],['','Explainability with SHAP','What a Shapley value means, computed by hand.'],['','Language models on engineering documents','Retrieval, grounding and citation.'],['','Multi-agent systems','Roles, hand-offs and self-checking answers.'],['','Evaluating AI systems','Metrics, test sets, drift and cost.']]},
 {name:'Economics, safety and digital',blurb:'The business and risk wrapper.',topics:[['','Production economics','NPV, decline, payback and price sensitivity.'],['','Emissions accounting','Methane intensity and monitoring options.'],['','Digital twins','What they are and what they are not.'],['','OT cybersecurity basics','Segmentation, access and monitoring.'],['','Data standards and open datasets','OSDU and Volve as learning material.']]}
];

/* ---------- app shell ---------- */
const NAV=[['dashboard','Dashboard'],['competitors','Competitors'],['ai','AI Hub'],['archive','Archive'],['tutorials','Tutorials'],['plan','Build plan']];
const ICONS={
  dashboard:'<path d="M4 20V11M12 20V5M20 20v-7"/>',
  competitors:'<circle cx="9" cy="12" r="6"/><circle cx="15" cy="12" r="6"/>',
  ai:'<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/>',
  archive:'<path d="M3 7l2-4h14l2 4"/><rect x="3" y="7" width="18" height="13" rx="1"/><line x1="9" y1="12" x2="15" y2="12"/>',
  tutorials:'<path d="M4 19.5V6a2 2 0 0 1 2-2h7v16H6a2 2 0 0 0-2 2z"/><path d="M20 19.5V6a2 2 0 0 0-2-2h-7v16h7a2 2 0 0 1 2 2z"/>',
  plan:'<path d="M3 6l6-2 6 2 6-2v14l-6 2-6-2-6 2z"/><path d="M9 4v14M15 6v14"/>'
};
/* ---------- guided tour: plain-language walkthrough of the whole app ---------- */
const TOUR=[
  {t:'Welcome to Wellhead',icon:ICONS.ai,body:'Wellhead does two things: it keeps you up to date on the oil and gas industry, and it teaches you how wells actually work, with hands-on lessons you can try yourself. This quick tour takes about 30 seconds \u2014 skip it any time.'},
  {t:'Dashboard',icon:ICONS.dashboard,body:'Your home page. The latest oil and gas headlines, grouped by source, checked every hour automatically.',page:'dashboard'},
  {t:'Competitors',icon:ICONS.competitors,body:'The same kind of news, filtered down to just the companies that compete with Honeywell in this space.',page:'competitors'},
  {t:'AI Hub',icon:ICONS.ai,body:'Everything about AI in one place: global AI news, practical best-practice tips, and a directory of tools with links to learn more about each.',page:'ai'},
  {t:'Archive',icon:ICONS.archive,body:'Every article is filed under the day it was published, so you can always look back and find what happened on a given date.',page:'archive'},
  {t:'Tutorials',icon:ICONS.tutorials,body:'This is where you learn. Each lesson explains the idea in plain words and in technical terms, works through a formula step by step, and gives you sliders to drag so you can see the result change live.',page:'tutorials'},
  {t:'Build plan',icon:ICONS.plan,body:'A behind-the-scenes look at how the live, always-updating version works \u2014 for anyone curious about the engineering underneath.',page:'plan'}
];
let tourI=0;
function renderTour(){
  const scrim=$('#tourScrim');if(!scrim)return;
  const s=TOUR[tourI];
  $('#tourBody').innerHTML=`<div class="tourico"><svg viewBox="0 0 24 24" aria-hidden="true">${s.icon}</svg></div>
    <div class="step">Step ${tourI+1} of ${TOUR.length}</div><h2>${esc(s.t)}</h2><p>${esc(s.body)}</p>
    ${tourI===0?`<div class="tourgrid">${TOUR.slice(1).map(x=>`<div class="mini2"><svg viewBox="0 0 24 24" aria-hidden="true">${x.icon}</svg>${esc(x.t)}</div>`).join('')}</div>`:''}
    <div class="tourfoot"><div class="tourdots">${TOUR.map((_,i)=>`<span class="${i===tourI?'on':''}"></span>`).join('')}</div>
    <div class="tourbtns">${tourI>0?'<button class="btn ghost" id="tourBack">Back</button>':'<button class="btn ghost" id="tourSkip">Skip</button>'}<button class="btn" id="tourNext">${tourI<TOUR.length-1?'Next':'Start exploring'}</button></div></div>`;
  $('#tourNext').addEventListener('click',()=>{if(tourI<TOUR.length-1){tourI++;renderTour()}else closeTour(true)});
  const back=$('#tourBack');if(back)back.addEventListener('click',()=>{tourI--;renderTour()});
  const skip=$('#tourSkip');if(skip)skip.addEventListener('click',()=>closeTour(true));
}
function openTour(){
  tourI=0;
  const d=document.createElement('div');d.className='scrim';d.id='tourScrim';
  d.innerHTML='<div class="tourcard" role="dialog" aria-modal="true" aria-label="Guided tour" id="tourBody"></div>';
  document.body.appendChild(d);
  d.addEventListener('click',e=>{if(e.target===d)closeTour(true)});
  document.addEventListener('keydown',tourEsc);
  renderTour();
  const first=$('#tourNext',d)||d;if(first)first.focus&&first.focus();
}
function tourEsc(e){if(e.key==='Escape')closeTour(true)}
function closeTour(markSeen){
  const d=$('#tourScrim');if(d)d.remove();
  document.removeEventListener('keydown',tourEsc);
  if(markSeen)store.set('wh.tourSeen',true);
}
const main=$('#main'),ui={og:{f:'all',q:'',n:20},comp:{f:'all',q:'',n:20},ai:{f:'all',q:'',n:20,region:'all',relOnly:false},aiTab:'news',toolCat:'all',toolQ:'',archFeed:'og',archDay:null};
let redraws=[],refreshing=false;
feedListeners.add(()=>redraws.forEach(f=>f()));

function statusBar(){
  return`<div class="status"><span class="grow">${isDemo()?'<b>Demo data.</b> These headlines are placeholders that show how sources, hourly refresh and the dated archive behave. Connect the feed service (see Build plan) to show real articles.':'Live feed connected.'}</span><span>Last checked <b id="lastchk"></b></span><span>Next check in <b id="nextchk"></b></span><button class="btn ghost" id="rf">Check now</button></div>`;
}
function wireStatus(){
  const b=$('#rf');if(!b)return;
  b.addEventListener('click',async()=>{b.disabled=true;b.textContent='Checking\u2026';const r=await refreshFeeds(true);b.disabled=false;b.textContent=r.error?r.error:`Checked: ${r.added} new`;tick();setTimeout(()=>{if(b.isConnected)b.textContent='Check now'},3000)});
  tick();
}
function tick(){
  const l=$('#lastchk'),n=$('#nextchk'),left=FS.last+HOUR-Date.now();
  if(l)l.textContent=FS.last?clock(FS.last):'never';
  if(n)n.textContent=left>0?Math.ceil(left/60000)+' min':'now';
  if(left<=0&&!refreshing){refreshing=true;refreshFeeds().finally(()=>{refreshing=false;tick()})}
}
setInterval(tick,30000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)tick()});

function itemHTML(it){
  const s=SMAP[it.src],url=s?s.url:(it.url||'#'),t=esc(itemTitle(it));
  const head=it.live&&it.url?`<a href="${esc(it.url)}" target="_blank" rel="noopener">${t}</a>`:t;
  return`<article class="item"><div class="when"><b>${clock(it.pubAt)}</b>${ago(it.pubAt)}</div><div><h3>${head}</h3><p>${esc(itemSummary(it))}</p><div class="meta"><a class="s" href="${esc(url)}" target="_blank" rel="noopener">${esc(itemSrcName(it))}</a>${it.company?`<span class="tag co">${esc(CMAP[it.company].name)}</span>`:''}<span class="tag">${esc(itemTag(it))}</span>${it.region?`<span class="tag">${esc(it.region)}</span>`:''}${it.industryRelevant?'<span class="tag co">\u26A1 Energy/industrial</span>':''}${it.demo?'<span class="tag demo">Demo</span>':''}</div></div></article>`;
}
function feedPanel(host,feed,opts={}){
  const st=ui[feed],chips=feed==='comp'?COMPANIES:SRC[feed];
  host.innerHTML=`<div class="tools" role="group" aria-label="Filter by ${feed==='comp'?'company':'source'}"><button class="chip" data-f="all">All</button>${chips.map(c=>`<button class="chip" data-f="${c.id}">${esc(c.name)}</button>`).join('')}</div>
  <div class="tools"><input type="search" placeholder="Search headlines" aria-label="Search headlines" value="${esc(st.q)}" style="flex:1 1 200px">${feed==='ai'?`<select aria-label="Region"><option value="all">All regions</option>${REGIONS.map(r=>`<option${st.region===r?' selected':''}>${r}</option>`).join('')}</select><button class="chip" id="relToggle" aria-pressed="${st.relOnly}" style="border-color:var(--brand)">\u26A1 Energy &amp; industrial AI only</button>`:''}</div><div class="list"></div>`;
  const list=$('.list',host);
  const draw=()=>{
    $$('.chip[data-f]',host).forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.f===st.f)));
    const rt=$('#relToggle',host);if(rt)rt.setAttribute('aria-pressed',String(st.relOnly));
    let items=itemsFor(feed);
    if(opts.day)items=items.filter(i=>dayKey(i.pubAt)===opts.day);else{const cut=Date.now()-72*HOUR;items=items.filter(i=>i.pubAt>=cut)}
    if(st.f!=='all')items=items.filter(i=>(feed==='comp'?i.company:i.src)===st.f);
    if(feed==='ai'&&st.region!=='all')items=items.filter(i=>i.region===st.region);
    if(feed==='ai'&&st.relOnly)items=items.filter(i=>i.industryRelevant);
    if(st.q){const q=st.q.toLowerCase();items=items.filter(i=>(itemTitle(i)+' '+itemSrcName(i)+' '+itemTag(i)).toLowerCase().includes(q))}
    if(!items.length){list.innerHTML=`<p class="empty">No items match.${feed==='ai'&&st.relOnly?' Few AI articles mention oil, gas or energy by name \u2014 try turning off "Energy & industrial AI only", or check back after the next hourly refresh.':' Clear the filters or check another day in the Archive.'}</p>`;return}
    let h='',lastDay='';
    items.slice(0,opts.day?400:st.n).forEach(it=>{const k=dayKey(it.pubAt);if(k!==lastDay){h+=`<div class="day">${esc(dayLabel(k))}</div>`;lastDay=k}h+=itemHTML(it)});
    if(!opts.day&&items.length>st.n)h+=`<div class="btns"><button class="btn ghost" id="more">Show ${Math.min(20,items.length-st.n)} more</button></div>`;
    if(!opts.day)h+=`<p class="empty">Items older than 3 days are filed by date in the <a href="#/archive">Archive</a>.</p>`;
    list.innerHTML=h;
    const m=$('#more',list);if(m)m.addEventListener('click',()=>{st.n+=20;draw()});
  };
  host.addEventListener('click',e=>{
    const rt=e.target.closest('#relToggle');if(rt){st.relOnly=!st.relOnly;st.n=20;draw();return}
    const b=e.target.closest('.chip[data-f]');if(b){st.f=b.dataset.f;st.n=20;draw()}
  });
  $('input',host).addEventListener('input',e=>{st.q=e.target.value;st.n=20;draw()});
  const sel=$('select',host);if(sel)sel.addEventListener('change',e=>{st.region=e.target.value;draw()});
  redraws.push(draw);draw();
}

/* ---------- pages ---------- */
function pageDashboard(m){
  const done=store.get('wh.done',[]),next=READY.filter(i=>!done.includes(i)).slice(0,2);
  m.innerHTML=`<header class="ph"><h1>Oil and gas news</h1><p class="sub">Trade press and industry sources, checked every hour and filed by date.</p></header>${statusBar()}
  <div class="cols"><section id="fh"></section><aside>
   <div class="card"><h2>New here?</h2><p style="margin:0 0 10px">Take a 30-second tour of the whole app, or jump straight into your first lesson.</p><div class="btns"><button class="btn" id="tourBtn">Take the tour</button><a class="btn ghost" href="#/t/hydrostatic" style="text-decoration:none">Start first tutorial</a></div></div>
   <div class="card"><h2>Competitor watch</h2><div id="sc"></div><p style="margin:10px 0 0"><a href="#/competitors">All competitor news</a></p></div>
   <div class="card"><h2>Sources, last 24 hours</h2><ul class="srclist">${SRC.og.map(s=>`<li><a href="${s.url}" target="_blank" rel="noopener">${esc(s.name)}</a><b id="c-${s.id}"></b></li>`).join('')}</ul></div>
   <div class="card"><h2>Continue learning</h2>${next.length?next.map(i=>`<div class="mini"><a href="#/t/${i}"><b>${esc(TUTS[i].title)}</b></a><span>${esc(TUTS[i].summary)}</span></div>`).join(''):'<p>All available tutorials completed.</p>'}<p style="margin:10px 0 0"><a href="#/tutorials">Browse the curriculum</a></p></div>
  </aside></div>`;
  wireStatus();feedPanel($('#fh'),'og');
  $('#tourBtn').addEventListener('click',openTour);
  const side=()=>{
    $('#sc').innerHTML=itemsFor('comp').slice(0,4).map(it=>`<div class="mini"><b>${esc(itemTitle(it))}</b><span>${esc(itemSrcName(it))}, ${ago(it.pubAt)}</span></div>`).join('');
    const cut=Date.now()-DAY;SRC.og.forEach(s=>{const el=$('#c-'+s.id);if(el)el.textContent=itemsFor('og').filter(i=>i.src===s.id&&i.pubAt>=cut).length});
  };
  side();redraws.push(side);
}
function pageComp(m){
  m.innerHTML=`<header class="ph"><h1>Competitor news</h1><p class="sub">Companies competing with Honeywell in oil, gas and energy automation and digital. There is no separate competitor news wire \u2014 every oil and gas article collected on the Dashboard is scanned for these names, so this page only fills up once several of those sources are working (check Dashboard's status line, or /status on the collector).</p></header>${statusBar()}
  <div id="fh"></div>
  <div class="card" style="margin-top:22px"><h2>Watchlist</h2><div class="scroll"><table class="t"><thead><tr><th>Company</th><th>Overlap area</th></tr></thead><tbody>${COMPANIES.map(c=>`<tr><td><a href="${c.url}" target="_blank" rel="noopener">${esc(c.name)}</a></td><td>${esc(c.area)}</td></tr>`).join('')}</tbody></table></div></div>`;
  wireStatus();feedPanel($('#fh'),'comp');
}
function pageAI(m){
  m.innerHTML=`<header class="ph"><h1>AI Hub</h1><p class="sub">AI news from across the whole field, not just energy \u2014 use the "\u26A1 Energy &amp; industrial AI only" filter below to narrow it to AI applied to oil, gas and industry.</p></header>
  <div class="tabs" role="tablist">${[['news','News and ideas'],['practice','Best practices'],['tools','Tools and sources']].map(t=>`<button role="tab" data-t="${t[0]}" aria-selected="${ui.aiTab===t[0]}">${t[1]}</button>`).join('')}</div><div id="tb"></div>`;
  const show=()=>{
    $$('.tabs button').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.t===ui.aiTab)));
    const tb=$('#tb');redraws=[];
    if(ui.aiTab==='news'){tb.innerHTML=statusBar()+'<div id="fh"></div>';wireStatus();feedPanel($('#fh'),'ai')}
    else if(ui.aiTab==='practice'){tb.innerHTML=`<div class="bp">${PRACTICES.map(p=>`<div class="card"><h3>${esc(p[0])}</h3><p>${esc(p[1])}</p></div>`).join('')}</div>`}
    else{
      tb.innerHTML=`<div class="tools"><button class="chip" data-c="all">All</button>${TOOL_CATS.map(c=>`<button class="chip" data-c="${c}">${c}</button>`).join('')}</div><div class="tools"><input type="search" placeholder="Search tools" aria-label="Search tools" value="${esc(ui.toolQ)}" style="flex:1 1 220px"></div><p class="sub" style="margin:4px 0 12px;color:var(--ink2)">Each card links to the official site. Check the licence and your company\u2019s approval rules before using any tool with company data.</p><div class="grid3" id="tg"></div>`;
      const dr=()=>{$$('.chip',tb).forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.c===ui.toolCat)));
        const q=ui.toolQ.toLowerCase(),l=TOOLS.filter(t=>(ui.toolCat==='all'||t.cat===ui.toolCat)&&(!q||(t.name+t.desc+t.cat).toLowerCase().includes(q)));
        $('#tg').innerHTML=l.length?l.map(t=>`<div class="tool"><h3>${esc(t.name)}</h3><div class="row"><span class="tag">${esc(t.cat)}</span><span class="tag">${esc(t.kind)}</span></div><p>${esc(t.desc)}</p><a href="${t.url}" target="_blank" rel="noopener">Official site and details</a></div>`).join(''):'<p class="empty">No tools match.</p>'};
      tb.addEventListener('click',e=>{const b=e.target.closest('.chip');if(b){ui.toolCat=b.dataset.c;dr()}});
      $('input',tb).addEventListener('input',e=>{ui.toolQ=e.target.value;dr()});dr();
    }
  };
  $('.tabs').addEventListener('click',e=>{const b=e.target.closest('button');if(b){ui.aiTab=b.dataset.t;show()}});
  show();
}
function pageArchive(m){
  m.innerHTML=`<header class="ph"><h1>Archive</h1><p class="sub">Every item is filed under the day it was published. Pick a feed and a day.</p></header>
  <div class="tabs" role="tablist">${Object.keys(FEEDS).map(f=>`<button role="tab" data-f="${f}" aria-selected="${ui.archFeed===f}">${FEEDS[f]}</button>`).join('')}</div>
  <div class="arch"><ul class="datelist" id="dl"></ul><div id="fh"></div></div>`;
  const show=()=>{
    $$('.tabs button').forEach(b=>b.setAttribute('aria-selected',String(b.dataset.f===ui.archFeed)));
    const items=itemsFor(ui.archFeed),days={};items.forEach(i=>{const k=dayKey(i.pubAt);days[k]=(days[k]||0)+1});
    const keys=Object.keys(days).sort().reverse();
    if(!ui.archDay||!days[ui.archDay])ui.archDay=keys[0];
    const dl=k=>{const b=new Date(k+'T12:00:00').toLocaleDateString('en-GB',{weekday:'short',day:'numeric',month:'short'});return k===dayKey(Date.now())?'Today, '+b:b};
    $('#dl').innerHTML=keys.map(k=>`<li><button data-d="${k}" aria-current="${k===ui.archDay}"><span>${dl(k)}</span><b>${days[k]}</b></button></li>`).join('')||'<li style="padding:12px">Nothing filed yet.</li>';
    redraws=[];
    if(ui.archDay)feedPanel($('#fh'),ui.archFeed,{day:ui.archDay});else $('#fh').innerHTML='';
  };
  $('.tabs').addEventListener('click',e=>{const b=e.target.closest('button');if(b){ui.archFeed=b.dataset.f;ui.archDay=null;show()}});
  $('#dl').addEventListener('click',e=>{const b=e.target.closest('button');if(b){ui.archDay=b.dataset.d;show()}});
  show();
}
function pageTutorials(m){
  const done=store.get('wh.done',[]),total=DOMAINS.reduce((n,d)=>n+d.topics.length,0);
  m.innerHTML=`<header class="ph"><h1>Tutorials</h1><p class="sub">${READY.length} tutorials are ready and interactive. ${total-READY.length} more are planned across ${DOMAINS.length} domains. ${done.length} of ${READY.length} completed.</p></header>
  <div class="card"><h2>How every tutorial is built</h2><p style="margin:0">Each concept is explained twice, once in plain words and once technically, and you can switch or read both. Formulas come with a worked example and a live calculator. Diagrams are SVG, and every idea has something to move, play or break.</p></div>
  ${DOMAINS.map(d=>`<section class="dom"><h2>${esc(d.name)}<small>${esc(d.blurb)}</small></h2><div class="topics">${d.topics.map(t=>{const r=t[0];return r?`<a class="topic ready" href="#/t/${r}"><b>${esc(t[1])}<em>${done.includes(r)?'Done':'Ready'}</em></b><span>${esc(t[2])}</span></a>`:`<div class="topic plan"><b>${esc(t[1])}<em>Planned</em></b><span>${esc(t[2])}</span></div>`}).join('')}</div></section>`).join('')}`;
}
function pageTutorial(id){
  const T=TUTS[id];
  if(!T){main.innerHTML='<p>Tutorial not found. <a href="#/tutorials">Back to tutorials</a></p>';return}
  let mode=store.get('wh.mode','both');const done=()=>store.get('wh.done',[]).includes(id);
  const idx=READY.indexOf(id),nx=READY[(idx+1)%READY.length];
  main.innerHTML=`<p style="margin:0 0 10px"><a href="#/tutorials">&larr; All tutorials</a></p>
  <div class="thead"><div><h1>${esc(T.title)}</h1><p class="sub" style="color:var(--ink2);margin:6px 0 0">${esc(T.domain)}, about ${T.min} minutes. ${esc(T.summary)}</p></div>
  <div><div class="modebar" role="group" aria-label="Explanation style">${[['lay','Plain words'],['both','Both'],['tech','Technical']].map(b=>`<button data-m="${b[0]}" aria-pressed="${mode===b[0]}">${b[1]}</button>`).join('')}</div>
  <p class="hintline">New to this topic? Start with "Plain words". Choose "Both" once you want the technical terms alongside.</p></div></div>
  <div class="tut mode-${mode}" id="tut">${T.build()}</div>
  <div class="btns"><button class="btn" id="done"></button><a class="btn ghost" href="#/t/${nx}" style="text-decoration:none">Next tutorial</a></div>`;
  const tut=$('#tut'),db=$('#done');
  const firstLab=$('.lab',tut);
  if(firstLab){const hint=document.createElement('p');hint.className='trybadge';hint.textContent='Try it \u2014 drag the sliders or press the buttons below, and watch the diagram update instantly.';firstLab.parentNode.insertBefore(hint,firstLab)}
  const lbl=()=>db.textContent=done()?'Completed. Undo':'Mark as completed';lbl();
  db.addEventListener('click',()=>{let d=store.get('wh.done',[]);d=d.includes(id)?d.filter(x=>x!==id):d.concat(id);store.set('wh.done',d);lbl()});
  $('.modebar').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;mode=b.dataset.m;store.set('wh.mode',mode);tut.className='tut mode-'+mode;$$('.modebar button').forEach(x=>x.setAttribute('aria-pressed',String(x===b)))});
  T.mount(tut);
}
function pagePlan(m){
  const box=(x,t,s)=>`<rect x="${x}" y="26" width="138" height="64" fill="var(--panel)" stroke="var(--ink)" stroke-width="1.5"/><text class="tx b" x="${x+69}" y="52" text-anchor="middle" style="font-size:14px;fill:var(--ink)">${t}</text><text class="tx" x="${x+69}" y="72" text-anchor="middle">${s}</text>`;
  const arr=x=>`<line x1="${x}" y1="58" x2="${x+16}" y2="58" stroke="var(--ink2)" stroke-width="2" marker-end="url(#ah2)"/>`;
  m.innerHTML=`<header class="ph"><h1>Build plan</h1><p class="sub">What this prototype does today, and what turns it into a live service.</p></header>
  <div class="card"><h2>Architecture for the live version</h2><svg class="chart" viewBox="0 0 800 120" role="img" aria-label="Sources feed a collector that runs hourly, stores dated articles in a database, and serves them through an API to the web app" style="max-width:860px"><defs><marker id="ah2" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0L10 5L0 10z" fill="var(--ink2)"/></marker></defs>
   ${box(6,'Sources','RSS, Atom, APIs')}${arr(146)}${box(164,'Collector','runs every hour')}${arr(304)}${box(322,'Database','one row per article')}${arr(462)}${box(480,'API','/api/feed')}${arr(620)}${box(638,'Wellhead app','this page')}</svg>
   <p style="margin:8px 0 0">The collector reads each source, removes duplicates, tags the company and topic, and files the article under its publication date. The web app then calls the API instead of using demo data. In the source file, set <code class="num">LIVE_API</code> to the API address.</p></div>
  <div class="card"><h2>Prototype versus live</h2><div class="scroll"><table class="t"><thead><tr><th>Feature</th><th>In this prototype</th><th>To go live</th></tr></thead><tbody>
   <tr><td>News and competitor feeds</td><td>Layout, source labels, filters, search. Placeholder items.</td><td>Collector reads the listed sources. Browsers cannot read most news sites directly, so a small server is needed.</td></tr>
   <tr><td>Hourly refresh</td><td>Runs while a browser tab is open.</td><td>Scheduled job on a server, running whether or not anyone is online.</td></tr>
   <tr><td>Date-wise archive</td><td>Saved in this browser only.</td><td>Database with the same date keys, shared by all users.</td></tr>
   <tr><td>Competitor tagging</td><td>Company filter on placeholder items.</td><td>Match company names and product terms in article text.</td></tr>
   <tr><td>AI Hub tools</td><td>${TOOLS.length} tools with official links.</td><td>Periodic link check and additions.</td></tr>
   <tr><td>Tutorials</td><td>${READY.length} complete and interactive.</td><td>Build the remaining ${DOMAINS.reduce((n,d)=>n+d.topics.length,0)-READY.length} in the order you choose.</td></tr></tbody></table></div></div>
  <div class="card"><h2>Questions to settle next</h2><ol style="margin:6px 0 0"><li>Which companies belong on the competitor watchlist?</li><li>Which additional sources should be read, including regional and non-English ones?</li><li>Where will this run (company server, cloud, or a laptop first), and who can see it?</li><li>Which two or three tutorial domains matter most this quarter?</li></ol></div>`;
}

/* ---------- router ---------- */
const PAGES={dashboard:pageDashboard,competitors:pageComp,ai:pageAI,archive:pageArchive,tutorials:pageTutorials,plan:pagePlan};
function route(){
  stopAnims();redraws=[];
  const h=location.hash.replace(/^#\/?/,'')||'dashboard',parts=h.split('/'),name=parts[0];
  $$('#nav a').forEach(a=>{const on=a.dataset.r===name||(name==='t'&&a.dataset.r==='tutorials');on?a.setAttribute('aria-current','page'):a.removeAttribute('aria-current')});
  if(name==='t')pageTutorial(parts[1]);else(PAGES[name]||pageDashboard)(main);
  window.scrollTo(0,0);
  document.title=(name==='t'&&TUTS[parts[1]]?TUTS[parts[1]].title:(NAV.find(n=>n[0]===name)||NAV[0])[1])+' | Wellhead';
}
$('#nav').innerHTML=NAV.map(n=>`<a href="#/${n[0]}" data-r="${n[0]}"><svg class="navi" viewBox="0 0 24 24" aria-hidden="true">${ICONS[n[0]]}</svg><span>${n[1]}</span></a>`).join('');
window.addEventListener('hashchange',route);
const themeBtn=$('#theme');
const savedTheme=store.get('wh.theme',null);if(savedTheme)document.documentElement.dataset.theme=savedTheme;
themeBtn.addEventListener('click',()=>{
  const cur=document.documentElement.dataset.theme||(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light');
  const nx=cur==='dark'?'light':'dark';document.documentElement.dataset.theme=nx;store.set('wh.theme',nx);
});
$('#help').addEventListener('click',openTour);
refreshFeeds().then(route,route);
if(!store.get('wh.tourSeen',false))setTimeout(openTour,400);
