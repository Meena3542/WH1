/* =====================================================================
   TUTORIAL 5: Reservoir fluids and PVT (Standing's Rs correlation)
   ===================================================================== */
const T_PVT={
  id:'pvt-rs',title:'Reservoir fluids and PVT: how much gas is dissolved in the oil',domain:'Well fundamentals',min:25,
  summary:'Solution gas-oil ratio from Standing\u2019s correlation, and why the bubble point matters.',
  build(){const ex=0.75*Math.pow(2000/18.2+1.4,1.2048)*Math.pow(10,0.0125*35-0.00091*180);return`
  ${sec('Why this matters',LT(
    `<p>Open a bottle of soda and bubbles appear: gas that was dissolved in the liquid comes out once the pressure drops. Reservoir oil works the same way. Deep underground, at high pressure, a lot of gas stays dissolved in the oil. As the oil rises up the well and pressure falls, that gas starts coming out of solution.</p>
     <p>The pressure at which the first bubble appears is called the bubble point. Below it, the oil and gas separate; above it, they travel together as one liquid.</p>`,
    `<p>The solution gas-oil ratio, R<sub>s</sub>, is the amount of gas (measured at surface conditions) that is dissolved in one stock-tank barrel of oil at a given reservoir pressure and temperature. R<sub>s</sub> rises with pressure up to the bubble point, then stays flat, because above the bubble point there is no free gas left to dissolve further. R<sub>s</sub> at the bubble point, R<sub>sb</sub>, is one of the three key PVT properties (with B<sub>o</sub> and B<sub>g</sub>) that reservoir engineering runs on.</p>`))}
  ${sec('The formula',`
    ${LT(`<p>Standing tested many California oils in the lab and fitted a single equation that predicts how much gas dissolves, from the oil's weight (API gravity), the gas's weight (specific gravity), the pressure and the temperature.</p>`,
         `<p>Standing's (1947) correlation, still a standard first estimate: heavier gas (higher &gamma;<sub>g</sub>), lighter oil (higher API) and higher pressure all raise R<sub>s</sub>; higher temperature lowers it.</p>`)}
    <div class="formula">R<sub>s</sub> = &gamma;<sub>g</sub> &times; (P/18.2 + 1.4)<sup>1.2048</sup> &times; 10<sup>(0.0125 &times; API &minus; 0.00091 &times; T)</sup></div>
    <dl class="vars"><dt>R<sub>s</sub></dt><dd>solution gas-oil ratio, scf per STB (below the bubble point)</dd><dt>&gamma;<sub>g</sub></dt><dd>gas specific gravity, air = 1</dd><dt>P</dt><dd>pressure, psia</dd><dt>API</dt><dd>stock-tank oil gravity, &deg;API</dd><dt>T</dt><dd>reservoir temperature, &deg;F</dd></dl>`)}
  ${sec('Worked example',`
    <div class="worked"><p><b>Problem.</b> Gas gravity 0.75, oil gravity 35&deg;API, reservoir temperature 180&deg;F, pressure 2,000 psia. Find R<sub>s</sub>.</p>
    <ol><li>Pressure term: <code>(2,000/18.2 + 1.4)<sup>1.2048</sup> = 111.3<sup>1.2048</sup> = ${fmt(Math.pow(111.3,1.2048),1)}</code></li>
    <li>Gravity/temperature term: <code>10<sup>(0.0125&times;35 &minus; 0.00091&times;180)</sup> = 10<sup>0.2737</sup> = ${fmt(Math.pow(10,0.2737),3)}</code></li>
    <li>R<sub>s</sub> = <code>0.75 &times; ${fmt(Math.pow(111.3,1.2048),1)} &times; ${fmt(Math.pow(10,0.2737),3)} = ${fmt(ex,0)} scf/STB</code></li></ol></div>`)}
  ${sec('Try it',`
  <div class="lab"><div class="lab-grid">
    <div>${slider('gg','Gas gravity &gamma;<sub>g</sub>',0.6,1.2,0.01,0.75)}${slider('api','Oil gravity',15,50,1,35)}${slider('T','Temperature',100,300,5,180)}${slider('pb','Bubble point pressure',1000,6000,50,3500)}
    <div class="btns"><button class="btn" id="play">Sweep bubble point</button></div><div class="read">${readBox('rRs','R<sub>s</sub> at bubble point')}</div></div>
    <svg id="ch" class="chart" viewBox="0 0 560 320" role="img" aria-label="Solution gas-oil ratio rising with pressure, then flattening above the bubble point"></svg>
  </div><div class="worked" id="live"></div></div>
  <div class="callout">Try this: raise the bubble point above the maximum reservoir pressure on the slider. The curve never flattens, because the oil never reaches saturation, which is exactly what "undersaturated" means.</div>`)}
  ${sec('Common mistakes',`<ul><li>Applying R<sub>s</sub> above the bubble point. Above it R<sub>s</sub> is fixed at R<sub>sb</sub>; use undersaturated oil compressibility instead.</li><li>Mixing up produced GOR (measured at surface, includes free gas) with R<sub>s</sub> (dissolved gas only).</li><li>Using Standing's correlation far outside the oils it was fitted to. Lab PVT data beats any correlation.</li></ul>`)}
  ${sec('References',`<ul class="refs"><li>Standing, M.B. (1947). A pressure-volume-temperature correlation for mixtures of California oils and gases. <em>Drilling and Production Practice</em>, API.</li><li>McCain, W.D. (1990). <em>The Properties of Petroleum Fluids</em>, 2nd ed. PennWell.</li></ul>`)}`},
  mount(root){
    function Rs(gg,api,T,P){return gg*Math.pow(P/18.2+1.4,1.2048)*Math.pow(10,0.0125*api-0.00091*T)}
    function upd(){
      const gg=+$('#gg',root).value,api=+$('#api',root).value,T=+$('#T',root).value,pb=+$('#pb',root).value;
      setOut(root,'ggo',gg.toFixed(2));setOut(root,'apio',api+'\u00B0');setOut(root,'To',T+'\u00B0F');setOut(root,'pbo',fmt(pb)+' psia');
      const rsb=Rs(gg,api,T,pb);setOut(root,'rRs',fmt(rsb)+' scf/STB');
      const ymax=niceMax(rsb*1.15),a=axes({w:560,h:320,x0:0,x1:6000,y0:0,y1:ymax,xs:1000,ys:ymax/5,xl:'Pressure (psia)',yl:'Rs (scf/STB)'});
      const pts=[];for(let P=0;P<=6000;P+=100){const p=Math.min(P,pb);pts.push([a.sx(P),a.sy(Rs(gg,api,T,p))])}
      let c=a.svg+`<path class="l-brand" d="${pathOf(pts)}"/><line class="mk" x1="${a.sx(pb)}" x2="${a.sx(pb)}" y1="${a.sy(0)}" y2="${a.sy(rsb)}"/><circle class="dot-b" cx="${a.sx(pb)}" cy="${a.sy(rsb)}" r="6"/><text class="tx b" x="${a.sx(pb)+6}" y="${a.sy(rsb)-8}">bubble point</text>`;
      $('#ch',root).innerHTML=c;
      $('#live',root).innerHTML=`<p><b>Your numbers</b></p><ol><li>Pressure term: <code>(${fmt(pb)}/18.2+1.4)<sup>1.2048</sup> = ${fmt(Math.pow(pb/18.2+1.4,1.2048),1)}</code></li><li>Gravity/temperature term: <code>10<sup>${(0.0125*api-0.00091*T).toFixed(4)}</sup> = ${fmt(Math.pow(10,0.0125*api-0.00091*T),3)}</code></li><li>R<sub>s</sub> = <code>${fmt(rsb)} scf/STB</code></li></ol>`;
    }
    $$('input',root).forEach(i=>i.addEventListener('input',upd));
    let stop=null;
    $('#play',root).addEventListener('click',()=>{
      if(stop){stop();return}const b=$('#play',root);b.textContent='Stop';let raf,t0=null;
      const fin=()=>{cancelAnimationFrame(raf);stop=null;b.textContent='Sweep bubble point'};
      const step=t=>{if(t0==null)t0=t;const k=clamp((t-t0)/4000,0,1);$('#pb',root).value=Math.round((1000+k*5000)/50)*50;upd();if(k<1)raf=requestAnimationFrame(step);else fin()};
      stop=regAnim(fin);raf=requestAnimationFrame(step);
    });
    upd();
  }
};

/* =====================================================================
   TUTORIAL 6: Phase behaviour and fluid classification
   ===================================================================== */
const T_PHASE={
  id:'phase-behavior',title:'Phase behaviour: what kind of fluid is down there',domain:'Well fundamentals',min:20,
  summary:'Black oil, volatile oil, gas condensate and dry gas, and the rough rules that tell them apart.',
  build(){return`
  ${sec('Why this matters',LT(
    `<p>Not all oil and gas reservoirs hold the same kind of fluid. Some hold a thick, dark oil that barely changes as it comes to surface. Others hold a fluid that looks like gas underground but leaves a trickle of liquid once it reaches the surface, the way breath fogs on a cold day. Knowing which kind you have decides what surface equipment you build.</p>`,
    `<p>Engineers classify reservoir fluids by their composition and by how they behave as pressure and temperature fall on the way to the surface, which shows up in a pressure&ndash;temperature phase diagram. In practice a quick classification uses two numbers everyone already measures: the produced gas-oil ratio (GOR) and the stock-tank liquid's API gravity.</p>`))}
  ${sec('The four families',`<div class="scroll"><table class="t"><thead><tr><th>Fluid type</th><th>Typical GOR</th><th>Typical stock-tank liquid</th><th>What happens at surface</th></tr></thead><tbody>
    <tr><td>Black oil</td><td>&lt; 1,000 scf/STB</td><td>API &lt; 45&deg;, often dark</td><td>Modest gas breakout, most volume stays liquid</td></tr>
    <tr><td>Volatile oil</td><td>1,000&ndash;3,000 scf/STB</td><td>API 40&ndash;50&deg;</td><td>Large gas breakout for a small pressure drop near the bubble point</td></tr>
    <tr><td>Gas condensate</td><td>3,000&ndash;100,000 scf/STB</td><td>API 40&ndash;60&deg;, often pale</td><td>Reservoir fluid is a gas; a liquid "condenses" out only after pressure and temperature fall enough</td></tr>
    <tr><td>Dry gas</td><td>&gt; 100,000 scf/STB (or no liquid at all)</td><td>little to none</td><td>Stays gas all the way to the sales line</td></tr>
    </tbody></table></div><p class="callout" style="margin-top:10px">These ranges are commonly used rules of thumb, not sharp boundaries \u2014 real fluids sit on a continuum, and different textbooks draw the lines slightly differently.</p>`)}
  ${sec('Try it',`
  <div class="lab"><div class="lab-grid">
    <div>${slider('gor','Producing GOR',50,150000,50,1800)}${slider('api2','Stock-tank API gravity',10,70,1,42)}<div id="verdict" style="margin-top:10px"></div></div>
    <svg id="map" class="chart" viewBox="0 0 480 340" role="img" aria-label="Classification map: GOR on a log scale against API gravity, divided into the four fluid families"></svg>
  </div></div>`)}
  ${sec('Common mistakes',`<ul><li>Reading too much into a single early well test. GOR often changes as a reservoir depletes, especially near the bubble point.</li><li>Confusing gas condensate (a gas reservoir that yields liquid) with volatile oil (a liquid reservoir that yields a lot of gas). They can have overlapping GOR but the reservoir fluid is different.</li><li>Treating the cutoffs as exact. They are a starting point for planning, not a lab result.</li></ul>`)}
  ${sec('References',`<ul class="refs"><li>McCain, W.D. (1990). <em>The Properties of Petroleum Fluids</em>, 2nd ed. PennWell: fluid classification by GOR and gravity.</li><li>Ahmed, T. (2010). <em>Reservoir Engineering Handbook</em>, 4th ed. Gulf Professional Publishing.</li></ul>`)}`},
  mount(root){
    const W=480,H=340,ml=54,mr=14,mt=16,mb=40,x0=10,x1=70;
    const sx=v=>ml+(v-x0)*(W-ml-mr)/(x1-x0);
    const ylog=v=>{const lo=Math.log10(50),hi=Math.log10(150000);return H-mb-(Math.log10(Math.max(50,v))-lo)*(H-mt-mb)/(hi-lo)};
    function draw(){
      const gor=+$('#gor',root).value,api=+$('#api2',root).value;
      setOut(root,'goro',fmt(gor)+' scf/STB');setOut(root,'api2o',api+'\u00B0 API');
      let s='';
      const bands=[[50,1000,'var(--wash)'],[1000,3000,'var(--amber-bg)'],[3000,100000,'var(--brand)'],[100000,150000,'var(--ink2)']];
      bands.forEach(([lo,hi,col],i)=>{s+=`<rect x="${ml}" y="${ylog(hi)}" width="${W-ml-mr}" height="${ylog(lo)-ylog(hi)}" fill="${col}" opacity="${i===2?0.18:i===3?0.15:0.5}"/>`});
      [50,200,1000,3000,10000,100000].forEach(v=>{s+=`<line class="gr" x1="${ml}" x2="${W-mr}" y1="${ylog(v)}" y2="${ylog(v)}"/><text class="tx" x="${ml-8}" y="${ylog(v)+4}" text-anchor="end">${fmt(v)}</text>`});
      [10,25,40,55,70].forEach(v=>{s+=`<line class="gr" x1="${sx(v)}" x2="${sx(v)}" y1="${mt}" y2="${H-mb}"/><text class="tx" x="${sx(v)}" y="${H-mb+16}" text-anchor="middle">${v}\u00B0</text>`});
      s+=`<line class="ax" x1="${ml}" x2="${W-mr}" y1="${H-mb}" y2="${H-mb}"/><line class="ax" x1="${ml}" x2="${ml}" y1="${mt}" y2="${H-mb}"/>`;
      s+=`<text class="tx b" x="${(ml+W-mr)/2}" y="${H-6}" text-anchor="middle">API gravity</text><text class="tx b" transform="translate(14 ${(mt+H-mb)/2}) rotate(-90)" text-anchor="middle">GOR (scf/STB, log scale)</text>`;
      const labels=[['Black oil',600,'var(--ink)'],['Volatile oil',1800,'var(--amber)'],['Gas condensate',15000,'var(--brand)'],['Dry gas',130000,'var(--ink2)']];
      labels.forEach(([t,v,col])=>{s+=`<text class="tx b" x="${W-mr-6}" y="${ylog(v)+4}" text-anchor="end" style="fill:${col}">${t}</text>`});
      s+=`<circle cx="${sx(api)}" cy="${ylog(gor)}" r="7" fill="var(--red)" stroke="var(--panel)" stroke-width="2"/>`;
      $('#map',root).innerHTML=s;
      const type=gor<1000?'Black oil':gor<3000?'Volatile oil':gor<100000?'Gas condensate':'Dry gas';
      $('#verdict',root).innerHTML=`<span class="pill ok">Closest match: ${type}</span>`;
    }
    $$('input',root).forEach(i=>i.addEventListener('input',draw));
    draw();
  }
};

/* =====================================================================
   TUTORIAL 7: Pore pressure, fracture pressure, the mud window (Eaton)
   ===================================================================== */
const T_MUD={
  id:'mud-window',title:'The mud-weight window: staying between pore pressure and fracture pressure',domain:'Well fundamentals',min:25,
  summary:'Eaton\u2019s fracture-gradient equation, and why the safe drilling range can be narrow.',
  build(){const Sob=10000,Pp=4650,nu=0.4,Pf=nu/(1-nu)*(Sob-Pp)+Pp;return`
  ${sec('Why this matters',LT(
    `<p>Tutorial 1 showed that mud must push back harder than the formation, or fluid flows in. There is also a ceiling: push too hard and the rock itself splits open, like over-inflating a tyre. The mud weight has to sit between these two limits, and sometimes that gap is uncomfortably narrow.</p>`,
    `<p>The floor is pore pressure, the pressure of fluid trapped in the rock. The ceiling is fracture pressure, the pressure at which the rock fails in tension. Between them is the mud-weight window that keeps a well both stable and controllable. Fracture pressure sits below the full weight of the overlying rock (overburden) because the rock also resists sideways, held back by its own confinement.</p>`))}
  ${sec('The formula',`
    ${LT(`<p>Rock does not just get squeezed from above, it also gets squeezed a bit from the sides, by its neighbours. How much of that sideways squeeze happens depends on how "squishy" the rock is (a property called Poisson's ratio). Eaton's formula turns that squishiness into a fracture pressure.</p>`,
         `<p>Eaton (1969) related fracture pressure to overburden and pore pressure through the rock's Poisson's ratio &nu;, a simplification of the horizontal stress that works well as a first design estimate. Ductile shales have higher &nu; (closer to 0.5), stiff sandstones lower &nu;, which is why fracture gradients vary by rock type at the same depth.</p>`)}
    <div class="formula">P<sub>f</sub> = &nu; / (1 &minus; &nu;) &times; (S<sub>ob</sub> &minus; P<sub>p</sub>) + P<sub>p</sub></div>
    <dl class="vars"><dt>P<sub>f</sub></dt><dd>fracture pressure, psi</dd><dt>&nu;</dt><dd>Poisson's ratio of the rock, dimensionless (typically 0.25&ndash;0.45)</dd><dt>S<sub>ob</sub></dt><dd>overburden (total vertical stress), psi</dd><dt>P<sub>p</sub></dt><dd>pore pressure, psi</dd></dl>`)}
  ${sec('Worked example',`
    <div class="worked"><p><b>Problem.</b> At 10,000 ft TVD, overburden gradient is 1.0 psi/ft, pore pressure gradient is 0.465 psi/ft (normal), and &nu; = 0.4. Find the fracture pressure and the mud-weight window.</p>
    <ol><li>Overburden: <code>1.0 &times; 10,000 = ${fmt(Sob)} psi</code>. Pore pressure: <code>0.465 &times; 10,000 = ${fmt(Pp)} psi</code></li>
    <li>Fracture pressure: <code>0.4/0.6 &times; (${fmt(Sob)} &minus; ${fmt(Pp)}) + ${fmt(Pp)} = ${fmt(Pf)} psi</code>, a gradient of <code>${(Pf/10000).toFixed(3)} psi/ft</code></li>
    <li>As mud weight: pore pressure needs at least <code>${(Pp/10000/0.052).toFixed(2)} ppg</code>; fracture pressure limits it to <code>${(Pf/10000/0.052).toFixed(2)} ppg</code>.</li>
    <li>The safe window here is about <code>${(Pf/10000/0.052-Pp/10000/0.052).toFixed(1)} ppg</code> wide. In deeper, more abnormally pressured wells this window can shrink to 1 ppg or less.</li></ol></div>`)}
  ${sec('Try it',`
  <div class="lab"><div class="lab-grid">
    <div>${slider('dep','Depth (TVD)',3000,20000,250,10000)}${slider('sg','Overburden gradient',0.85,1.1,0.01,1.0)}${slider('pg','Pore pressure gradient',0.4,0.9,0.005,0.465)}${slider('nu','Poisson\u2019s ratio',0.25,0.48,0.01,0.40)}${slider('mw','Chosen mud weight',7,19,0.1,10)}
    <div class="read">${readBox('rPp','Pore pressure')}${readBox('rPf','Fracture pressure')}${readBox('rW','Window width')}</div><div id="stat"></div></div>
    <svg id="ch" class="chart" viewBox="0 0 560 320" role="img" aria-label="Pore pressure and fracture pressure against depth, with the current mud weight line"></svg>
  </div><div class="worked" id="live"></div></div>
  <div class="callout">Try this: push the pore pressure gradient up toward 0.75 (an overpressured shale) while keeping the overburden gradient the same. Watch the window close.</div>`)}
  ${sec('Common mistakes',`<ul><li>Treating Poisson's ratio as one fixed number for a whole well. It changes formation by formation and needs updating at each casing point.</li><li>Ignoring temperature and time effects on fracture pressure in long, hot wells.</li><li>Designing to the edge of the window with no margin for surge and swab pressures while tripping pipe.</li></ul>`)}
  ${sec('References',`<ul class="refs"><li>Eaton, B.A. (1969). Fracture gradient prediction and its application in oilfield operations. <em>Journal of Petroleum Technology</em>, 21(10), 1353&ndash;1360.</li><li>Rabia, H. (2001). <em>Well Engineering and Construction</em>. Entrac Consulting.</li></ul>`)}`},
  mount(root){
    function upd(){
      const dep=+$('#dep',root).value,sg=+$('#sg',root).value,pg=+$('#pg',root).value,nu=+$('#nu',root).value,mw=+$('#mw',root).value;
      setOut(root,'depo',fmt(dep)+' ft');setOut(root,'sgo',sg.toFixed(2)+' psi/ft');setOut(root,'pgo',pg.toFixed(3)+' psi/ft');setOut(root,'nuo',nu.toFixed(2));setOut(root,'mwo',mw.toFixed(1)+' ppg');
      const Sob=sg*dep,Pp=pg*dep,Pf=nu/(1-nu)*(Sob-Pp)+Pp,mwPore=Pp/dep/0.052,mwFrac=Pf/dep/0.052;
      setOut(root,'rPp',fmt(Pp)+' psi');setOut(root,'rPf',fmt(Pf)+' psi');setOut(root,'rW',(mwFrac-mwPore).toFixed(2)+' ppg');
      const st=$('#stat',root);
      if(mw<mwPore)st.innerHTML='<span class="pill bad">Below pore pressure: kick risk</span>';
      else if(mw>mwFrac)st.innerHTML='<span class="pill bad">Above fracture pressure: lost circulation risk</span>';
      else st.innerHTML='<span class="pill ok">Inside the window</span>';
      const ymax=niceMax(dep*1.05),a=axes({w:560,h:320,x0:0,x1:20000,y0:ymax,y1:0,xs:4000,ys:-ymax/5,xl:'Pressure (psi)',yl:'Depth (ft)'});
      const fg=nu/(1-nu)*(sg-pg)+pg;
      let c=a.svg;
      c+=`<path class="ok-fill" d="M${a.sx(0)} ${a.sy(0)}L${a.sx(pg*20000)} ${a.sy(20000)}L${a.sx(fg*20000)} ${a.sy(20000)}Z"/>`;
      c+=`<path class="l-amber" d="M${a.sx(0)} ${a.sy(0)}L${a.sx(pg*20000)} ${a.sy(20000)}"/>`;
      c+=`<path class="l-red" d="M${a.sx(0)} ${a.sy(0)}L${a.sx(fg*20000)} ${a.sy(20000)}"/>`;
      c+=`<line class="mk" x1="${a.ml}" x2="${a.w-a.mr}" y1="${a.sy(dep)}" y2="${a.sy(dep)}"/>`;
      c+=`<circle class="dot-a" cx="${a.sx(pg*dep)}" cy="${a.sy(dep)}" r="6"/><circle class="dot-b" cx="${a.sx(fg*dep)}" cy="${a.sy(dep)}" r="6"/>`;
      c+=`<circle cx="${a.sx(mw*0.052*dep)}" cy="${a.sy(dep)}" r="6" fill="var(--red)" stroke="var(--panel)" stroke-width="2"/>`;
      c+=`<text class="tx b" x="${a.sx(pg*20000)-6}" y="${a.sy(20000)-8}" text-anchor="end" style="fill:var(--amber)">Pore pressure</text><text class="tx b" x="${a.sx(fg*20000)+6}" y="${a.sy(20000)-8}" style="fill:var(--red)">Fracture pressure</text>`;
      $('#ch',root).innerHTML=c;
      $('#live',root).innerHTML=`<p><b>Your numbers</b></p><ol><li>Overburden: <code>${sg.toFixed(2)} &times; ${fmt(dep)} = ${fmt(Sob)} psi</code>. Pore pressure: <code>${pg.toFixed(3)} &times; ${fmt(dep)} = ${fmt(Pp)} psi</code></li><li>Fracture pressure: <code>${nu.toFixed(2)}/${(1-nu).toFixed(2)} &times; (${fmt(Sob)} \u2212 ${fmt(Pp)}) + ${fmt(Pp)} = ${fmt(Pf)} psi</code></li><li>Window: <code>${mwPore.toFixed(2)}</code> to <code>${mwFrac.toFixed(2)} ppg</code></li></ol>`;
    }
    $$('input',root).forEach(i=>i.addEventListener('input',upd));
    upd();
  }
};
