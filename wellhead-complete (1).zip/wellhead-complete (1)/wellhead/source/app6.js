/* =====================================================================
   TUTORIAL 8: Units that trip people up
   ===================================================================== */
const T_UNITS={
  id:'units',title:'Units that trip people up',domain:'Well fundamentals',min:15,
  summary:'API gravity versus specific gravity, and quick reference conversions.',
  build(){return`
  ${sec('Why this matters',LT(
    `<p>Oil and gas work mixes several measurement systems that grew up in different countries and different decades: pounds and gallons alongside kilograms and litres, an oil-industry-only gravity scale, and gas volumes counted in thousands or millions. Getting a conversion wrong by even a factor of a hundred is an easy way to make a real mistake.</p>`,
    `<p>Most field units trace back to US customary units (psi, ppg, bbl, ft), while much of the world uses SI (bar, kg/m&sup3;, m&sup3;, m). API gravity is its own scale, defined so that water is 10&deg;, and higher numbers mean lighter oil.</p>`))}
  ${sec('The formula',`
    ${LT(`<p>API gravity is the oilfield's own way of saying how light or heavy an oil is. It is built so that plain water always reads 10 degrees, and lighter, more valuable oils read higher.</p>`,
         `<p>API gravity is defined from specific gravity (relative to water) by a fixed formula, chosen so 10&deg;API equals SG 1.000 (water) exactly.</p>`)}
    <div class="formula">API = 141.5 / SG &minus; 131.5 &nbsp;&nbsp;&nbsp; SG = 141.5 / (API + 131.5)</div>
    <dl class="vars"><dt>API</dt><dd>API gravity, &deg;API</dd><dt>SG</dt><dd>specific gravity of the oil at 60&deg;F, relative to water = 1.000</dd></dl>`)}
  ${sec('Worked example',`<div class="worked"><p><b>Problem.</b> A crude has SG 0.8498. What is its API gravity, and does that match a 35&deg;API oil?</p>
  <ol><li><code>API = 141.5/0.8498 \u2212 131.5 = ${fmt(141.5/0.8498-131.5,1)}\u00B0</code>. Yes, matches.</li><li>Checking the reverse: <code>SG = 141.5/(35+131.5) = ${fmt(141.5/(35+131.5),4)}</code>, the same value.</li></ol></div>`)}
  ${sec('Try it: gravity converter',`
  <div class="lab"><div class="ctl"><span>API gravity</span><input type="range" id="apiv" min="5" max="70" step="0.5" value="35"><output id="apivo"></output></div>
  <div class="ctl"><span>Specific gravity</span><input type="range" id="sgv" min="0.65" max="1.05" step="0.001" value="0.8498"><output id="sgvo"></output></div>
  <p id="link" style="color:var(--ink2)">Moving either slider updates the other \u2014 they describe the same oil.</p></div>`)}
  ${sec('Quick reference table',`<div class="scroll"><table class="t"><thead><tr><th>Quantity</th><th>Conversion</th></tr></thead><tbody>
    <tr><td>Pressure</td><td>1 psi = 0.0689 bar = 6.895 kPa &nbsp;\u2014&nbsp; 1 bar = 14.50 psi</td></tr>
    <tr><td>Mud weight</td><td>1 ppg = 119.8 kg/m&sup3; = 0.05194 psi/ft &nbsp;\u2014&nbsp; 8.33 ppg = fresh water</td></tr>
    <tr><td>Volume</td><td>1 bbl = 42 US gal = 0.1590 m&sup3; &nbsp;\u2014&nbsp; 1 m&sup3; = 6.29 bbl</td></tr>
    <tr><td>Gas volume</td><td>1 Mscf = 1,000 scf &nbsp;\u2014&nbsp; 1 MMscf = 1,000,000 scf</td></tr>
    <tr><td>Length</td><td>1 ft = 0.3048 m &nbsp;\u2014&nbsp; 1 m = 3.281 ft</td></tr>
    <tr><td>Rate</td><td>1 STB/d = 0.1590 m&sup3;/d</td></tr>
  </tbody></table></div>`)}
  ${sec('Common mistakes',`<ul><li>Using measured depth where the formula needs true vertical depth (see tutorial 1).</li><li>Forgetting API gravity runs backwards: a higher number means a lighter oil, the opposite of specific gravity.</li><li>Mixing Mscf and MMscf in the same calculation. Always write the unit next to the number.</li></ul>`)}
  ${sec('References',`<ul class="refs"><li>API gravity is defined by the American Petroleum Institute; see API Manual of Petroleum Measurement Standards, Chapter 11.1, for the reference tables.</li></ul>`)}`},
  mount(root){
    let lock=false;
    function fromApi(){if(lock)return;lock=true;const a=+$('#apiv',root).value;$('#sgv',root).value=(141.5/(a+131.5)).toFixed(4);setOut(root,'apivo',a.toFixed(1)+'\u00B0');setOut(root,'sgvo',(+$('#sgv',root).value).toFixed(4));lock=false}
    function fromSg(){if(lock)return;lock=true;const s=+$('#sgv',root).value;$('#apiv',root).value=(141.5/s-131.5).toFixed(1);setOut(root,'sgvo',s.toFixed(4));setOut(root,'apivo',(+$('#apiv',root).value).toFixed(1)+'\u00B0');lock=false}
    $('#apiv',root).addEventListener('input',fromApi);
    $('#sgv',root).addEventListener('input',fromSg);
    fromApi();
  }
};
