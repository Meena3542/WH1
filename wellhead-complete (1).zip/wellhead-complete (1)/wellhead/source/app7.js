/* =====================================================================
   TUTORIAL 9: Darcy's law and radial flow
   ===================================================================== */
const T_DARCY={
  id:'darcy-radial',title:'Darcy\u2019s law: where the productivity index comes from',domain:'Reservoir and inflow',min:30,
  summary:'Radial flow into a wellbore, and how rock and fluid properties combine into one number, J.',
  build(){const q0=0.00708*50*40*(3000-2200)/(1.5*1.2*(Math.log(1000/0.328)-0.75));return`
  ${sec('Why this matters',LT(
    `<p>Tutorial 2 used a single number, J, to say how easily a well flows. This tutorial opens that number up. Oil moves toward a well the way water moves toward a drain: from all directions, faster as it gets close, through whatever the rock lets it through.</p>`,
    `<p>Darcy's law describes flow through porous rock. For flow converging on a single well from all sides (radial flow) at pseudo-steady state, integrating Darcy's law from the drainage radius down to the wellbore gives one closed-form rate equation. Almost every well-inflow model in production engineering starts here.</p>`))}
  ${sec('The formula',`
    ${LT(`<p>How much oil flows in depends on: how much pressure difference is pulling it (the drop from the edge of the drainage area to the well), how open the rock is (permeability) and how thick the productive layer is, divided by how thick and sticky the oil is, and by how far the oil has to travel plus any extra damage near the wellbore.</p>`,
         `<p>The log term ln(r<sub>e</sub>/r<sub>w</sub>) comes from integrating 1/r over the radial flow path; the &minus;0.75 is the pseudo-steady-state shape factor for a well centred in a circular drainage area; skin s adds extra pressure drop from near-wellbore damage or stimulation (negative s helps, positive s hurts).</p>`)}
    <div class="formula">q = 0.00708 &times; k h (P<sub>e</sub> &minus; P<sub>wf</sub>) / [&mu; B (ln(r<sub>e</sub>/r<sub>w</sub>) &minus; 0.75 + s)]</div>
    <dl class="vars"><dt>q</dt><dd>oil rate, STB/d</dd><dt>k</dt><dd>permeability, md</dd><dt>h</dt><dd>net pay thickness, ft</dd><dt>P<sub>e</sub>, P<sub>wf</sub></dt><dd>drainage-boundary and flowing bottomhole pressure, psi</dd><dt>&mu;</dt><dd>oil viscosity, cp</dd><dt>B</dt><dd>oil formation volume factor, rb/STB</dd><dt>r<sub>e</sub>, r<sub>w</sub></dt><dd>drainage and wellbore radius, ft</dd><dt>s</dt><dd>skin factor, dimensionless</dd></dl>`)}
  ${sec('Worked example',`<div class="worked"><p><b>Problem.</b> k = 50 md, h = 40 ft, &mu; = 1.5 cp, B = 1.2 rb/STB, r<sub>e</sub> = 1,000 ft, r<sub>w</sub> = 0.328 ft, s = 0, P<sub>e</sub> = 3,000 psi, P<sub>wf</sub> = 2,200 psi.</p>
  <ol><li><code>ln(1000/0.328) &minus; 0.75 = ${(Math.log(1000/0.328)-0.75).toFixed(3)}</code></li>
  <li><code>q = 0.00708 &times; 50 &times; 40 &times; 800 / (1.5 &times; 1.2 &times; ${(Math.log(1000/0.328)-0.75).toFixed(3)}) = ${fmt(q0)} STB/d</code></li>
  <li>So <code>J = ${fmt(q0)}/800 = ${(q0/800).toFixed(3)}</code> STB/d per psi \u2014 the same kind of number used directly in tutorial 2.</li></ol></div>`)}
  ${sec('Try it',`
  <div class="lab"><div class="lab-grid">
    <div>${slider('k','Permeability k',1,500,1,50)}${slider('h','Net pay h',5,150,5,40)}${slider('mu','Viscosity &mu;',0.2,10,0.1,1.5)}${slider('re','Drainage radius r<sub>e</sub>',200,3000,50,1000)}${slider('sk','Skin s',-5,20,1,0)}${slider('pwf','Flowing bottomhole P',500,2900,25,2200)}</div>
    <svg id="ch" class="chart" viewBox="0 0 560 320" role="img" aria-label="Rate against flowing bottomhole pressure, with and without the chosen skin"></svg>
  </div><div class="read">${readBox('rQ','Rate at this Pwf')}${readBox('rJ','Productivity index J')}</div><div class="worked" id="live"></div></div>
  <div class="callout">Try this: push skin from 0 up to 20 (severe damage) and watch how much rate that alone costs, at the very same rock and pressure. Then try a negative skin, as a stimulated or fractured well would show.</div>`)}
  ${sec('Common mistakes',`<ul><li>Using an average reservoir permeability when near-wellbore damage (skin) is what is actually limiting the well. Skin and average k affect production very differently.</li><li>Forgetting the 0.00708 constant is for field units (md, ft, cp, psi, STB/d). Different unit systems need a different constant.</li><li>This equation is for pseudo-steady-state, single-phase liquid flow above the bubble point. Below the bubble point, use Vogel (tutorial 2) instead.</li></ul>`)}
  ${sec('References',`<ul class="refs"><li>Darcy, H. (1856). <em>Les Fontaines Publiques de la Ville de Dijon</em>.</li><li>Dake, L.P. (1978). <em>Fundamentals of Reservoir Engineering</em>. Elsevier.</li><li>Economides, Hill, Ehlig-Economides &amp; Zhu (2013). <em>Petroleum Production Systems</em>, 2nd ed. Prentice Hall.</li></ul>`)}`},
  mount(root){
    function q(k,h,Pe,Pwf,mu,B,re,rw,s){return 0.00708*k*h*(Pe-Pwf)/(mu*B*(Math.log(re/rw)-0.75+s))}
    const rw=0.328,B=1.2,Pe=3000;
    function upd(){
      const k=+$('#k',root).value,h=+$('#h',root).value,mu=+$('#mu',root).value,re=+$('#re',root).value,sk=+$('#sk',root).value,pwf=+$('#pwf',root).value;
      setOut(root,'ko',fmt(k)+' md');setOut(root,'ho',fmt(h)+' ft');setOut(root,'muo',mu.toFixed(1)+' cp');setOut(root,'reo',fmt(re)+' ft');setOut(root,'sko',sk);setOut(root,'pwfo',fmt(pwf)+' psi');
      const qv=q(k,h,Pe,pwf,mu,B,re,rw,sk),J=qv/(Pe-pwf);
      setOut(root,'rQ',fmt(qv)+' STB/d');setOut(root,'rJ',J.toFixed(3));
      const qmax=niceMax(q(k,h,Pe,500,mu,B,re,rw,Math.min(sk,0))*1.05),a=axes({w:560,h:320,x0:0,x1:Pe,y0:0,y1:qmax,xs:500,ys:qmax/5,xl:'Flowing bottomhole pressure (psi)',yl:'Rate (STB/d)'});
      const pts=[],pts0=[];for(let p=0;p<=Pe;p+=100){pts.push([a.sx(p),a.sy(q(k,h,Pe,p,mu,B,re,rw,sk))]);pts0.push([a.sx(p),a.sy(q(k,h,Pe,p,mu,B,re,rw,0))])}
      let c=a.svg;
      if(sk!==0)c+=`<path class="l-grey" d="${pathOf(pts0)}"/><text class="tx" x="${a.sx(200)}" y="${a.sy(q(k,h,Pe,200,mu,B,re,rw,0))-6}">skin = 0</text>`;
      c+=`<path class="l-brand" d="${pathOf(pts)}"/><circle class="dot-b" cx="${a.sx(pwf)}" cy="${a.sy(qv)}" r="6"/>`;
      $('#ch',root).innerHTML=c;
      $('#live',root).innerHTML=`<p><b>Your numbers</b></p><ol><li><code>ln(${fmt(re)}/${rw}) \u2212 0.75 + ${sk} = ${(Math.log(re/rw)-0.75+sk).toFixed(3)}</code></li><li><code>q = 0.00708 &times; ${fmt(k)} &times; ${fmt(h)} &times; ${fmt(Pe-pwf)} / (${mu.toFixed(1)} &times; ${B} &times; ${(Math.log(re/rw)-0.75+sk).toFixed(3)}) = ${fmt(qv)} STB/d</code></li></ol>`;
    }
    $$('input',root).forEach(i=>i.addEventListener('input',upd));
    upd();
  }
};
