/* =====================================================================
   TUTORIAL 10: Drive mechanisms
   ===================================================================== */
const DRIVES={
  solution:{name:'Solution gas drive',rec:[5,30],shape:(x)=>1-0.85*Math.pow(x,0.6),gor:(x)=>1+7*Math.pow(x,1.6),
    note:'Gas that was dissolved in the oil comes out and expands, pushing oil toward the well. Once enough gas has broken out it flows too easily itself, and pressure falls fast.'},
  gascap:{name:'Gas-cap drive',rec:[20,40],shape:(x)=>1-0.55*Math.pow(x,0.9),gor:(x)=>1+3*Math.pow(x,1.2),
    note:'A free gas cap above the oil expands as oil is produced, topping up some of the pressure. Decline is gentler than solution gas drive alone.'},
  water:{name:'Water drive',rec:[35,75],shape:(x)=>1-0.15*Math.pow(x,1.3),gor:(x)=>1+0.6*x,
    note:'Water from an underlying or adjoining aquifer moves in to replace produced volume, so pressure can stay close to its original value for a long time.'}
};
const T_DRIVE={
  id:'drive-mechanisms',title:'Drive mechanisms: what keeps a reservoir\u2019s pressure up',domain:'Reservoir and inflow',min:20,
  summary:'Solution gas, gas cap and water drive, compared side by side.',
  build(){return`
  ${sec('Why this matters',LT(
    `<p>Squeeze an empty plastic bottle and it collapses; squeeze one with a balloon of air inside and it pushes back for a while. A reservoir behaves similarly: something has to fill the space left behind as oil is produced, and what does that job determines how the reservoir's pressure, and how much oil is ultimately recovered.</p>`,
    `<p>The "drive mechanism" is whichever source of energy replaces produced reservoir volume: expanding solution gas, an expanding gas cap, or water influx from an aquifer. Most real reservoirs are a mix, but it helps to understand the three pure cases first.</p>`))}
  ${sec('Why there is no single formula here',`<p>Unlike the other tutorials, drive mechanism is a description of reservoir behaviour rather than one equation. Engineers infer it from production history (pressure, GOR and water-cut trends) and confirm it with material balance (tutorial coming up) and geological data. The chart below shows the qualitative shape each drive produces, not a specific well's simulation.</p>`)}
  ${sec('Try it',`
  <div class="lab"><div class="lab-grid">
    <div class="tools" role="group" aria-label="Choose a drive mechanism">${Object.keys(DRIVES).map(k=>`<button class="chip" data-d="${k}">${DRIVES[k].name}</button>`).join('')}</div>
    <div id="note" class="worked" style="margin-top:8px"></div></div>
    <div><svg id="ch" class="chart" viewBox="0 0 560 300" role="img" aria-label="Illustrative pressure decline against recovery for the selected drive mechanism"></svg>
    <svg id="ch2" class="chart" viewBox="0 0 560 220" role="img" aria-label="Illustrative gas-oil ratio trend against recovery"></svg></div>
  </div></div>`)}
  ${sec('Typical ultimate recovery',`<div class="scroll"><table class="t"><thead><tr><th>Drive mechanism</th><th>Typical recovery factor</th></tr></thead><tbody>
  ${Object.values(DRIVES).map(d=>`<tr><td>${d.name}</td><td>${d.rec[0]}\u2013${d.rec[1]}% of oil in place</td></tr>`).join('')}
  </tbody></table></div><p class="callout" style="margin-top:10px">These ranges are commonly cited approximations. Actual recovery depends heavily on rock quality, fluid properties and how the field is managed, including artificial lift and pressure maintenance by injection.</p>`)}
  ${sec('Common mistakes',`<ul><li>Assuming a reservoir has one pure drive mechanism for its whole life. Many fields shift, for example from solution gas drive early on to a combination drive once water injection starts.</li><li>Reading drive mechanism from pressure alone. GOR and water-cut trends are just as telling.</li><li>Expecting the illustrative shapes here to match a specific field. They show the pattern, not a forecast.</li></ul>`)}
  ${sec('References',`<ul class="refs"><li>Craft, B.C. &amp; Hawkins, M.F. (1991). <em>Applied Petroleum Reservoir Engineering</em>, 2nd ed. Prentice Hall.</li><li>Ahmed, T. (2010). <em>Reservoir Engineering Handbook</em>, 4th ed. Gulf Professional Publishing.</li></ul>`)}`},
  mount(root){
    let cur='solution';
    function draw(){
      const d=DRIVES[cur];
      $$('.chip',root).forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.d===cur)));
      $('#note',root).innerHTML=`<p><b>${d.name}.</b> ${d.note} Typical ultimate recovery ${d.rec[0]}\u2013${d.rec[1]}% of oil in place.</p>`;
      const a=axes({w:560,h:300,x0:0,x1:1,y0:0,y1:1,xs:0.2,ys:0.2,xl:'Fraction of oil in place recovered',yl:'Reservoir pressure (fraction of initial)',fx:v=>Math.round(v*100)+'%',fy:v=>Math.round(v*100)+'%'});
      const pts=[];for(let i=0;i<=40;i++){const x=i/40*Math.min(1,d.rec[1]/100*1.3);pts.push([a.sx(x),a.sy(clamp(d.shape(x/(d.rec[1]/100)),0,1))])}
      $('#ch',root).innerHTML=a.svg+`<path class="l-brand" d="${pathOf(pts)}"/>`;
      const a2=axes({w:560,h:220,x0:0,x1:1,y0:0,y1:8,xs:0.2,ys:2,mb:38,xl:'Fraction of oil in place recovered',yl:'GOR (multiple of initial)',fx:v=>Math.round(v*100)+'%'});
      const pts2=[];for(let i=0;i<=40;i++){const x=i/40*Math.min(1,d.rec[1]/100*1.3);pts2.push([a2.sx(x),a2.sy(clamp(d.gor(x/(d.rec[1]/100)),1,8))])}
      $('#ch2',root).innerHTML=a2.svg+`<path class="l-amber" d="${pathOf(pts2)}"/>`;
    }
    root.addEventListener('click',e=>{const b=e.target.closest('.chip');if(b){cur=b.dataset.d;draw()}});
    draw();
  }
};
