/* =====================================================================
   TUTORIAL 11: Decline curve analysis (Arps)
   ===================================================================== */
function arpsQ(qi,D,b,t){return b<=1e-6?qi*Math.exp(-D*t):qi/Math.pow(1+b*D*t,1/b)}
function arpsNp(qi,D,b,t){
  const days=365.25;
  if(b<=1e-6)return days*qi/D*(1-Math.exp(-D*t));
  if(Math.abs(b-1)<1e-6)return days*qi/D*Math.log(qi/arpsQ(qi,D,b,t));
  return days*qi/(D*(1-b))*(1-Math.pow(1+b*D*t,1-1/b));
}
const T_DECLINE={
  id:'decline-curves',title:'Decline curve analysis: forecasting from the shape of the past',domain:'Reservoir and inflow',min:30,
  summary:'Arps\u2019s exponential, hyperbolic and harmonic curves, fitted to how a well is actually declining.',
  build(){const q3=arpsQ(1000,0.35,0.5,3),Np3=arpsNp(1000,0.35,0.5,3);return`
  ${sec('Why this matters',LT(
    `<p>A producing well's rate almost always falls over time, and usually in a recognisable shape. If you can name that shape, you can extend it forward, the same way you might guess where a thrown ball will land from watching the first part of its arc.</p>`,
    `<p>Arps (1945) noticed that most well declines fit one family of curves, controlled by a single shape parameter b. b = 0 is a constant fractional (exponential) decline; b = 1 is harmonic decline; values in between are hyperbolic. This remains the standard empirical forecasting method in reserves estimation, still used even though it has no strong theoretical basis.</p>`))}
  ${sec('The formula',`
    ${LT(`<p>The well starts at some rate and a decline speed. The "b" number says whether that speed itself is constant (fast, steady fade) or eases off with time (a long, thinning tail), which is often exactly what depletion-drive wells and many shale wells do.</p>`,
         `<p>D here is the nominal (continuous) initial decline rate. b = 0 gives the familiar exponential; larger b gives a slower-thinning tail, useful for wells with an increasing drainage area or changing drive mechanism.</p>`)}
    <div class="formula">q(t) = q<sub>i</sub> / (1 + b D t)<sup>1/b</sup> &nbsp;&nbsp; (b = 0: q(t) = q<sub>i</sub> e<sup>&minus;Dt</sup>)</div>
    <dl class="vars"><dt>q(t)</dt><dd>rate at time t, bbl/d</dd><dt>q<sub>i</sub></dt><dd>initial rate, bbl/d</dd><dt>D</dt><dd>initial nominal decline rate, per year</dd><dt>b</dt><dd>decline exponent, dimensionless (0 = exponential, 1 = harmonic)</dd><dt>t</dt><dd>time, years</dd></dl>
    <div class="callout">Cumulative production to time t has a closed form too: exponential N<sub>p</sub> = q<sub>i</sub>/D (1 &minus; e<sup>&minus;Dt</sup>); harmonic N<sub>p</sub> = (q<sub>i</sub>/D) ln(q<sub>i</sub>/q(t)); general hyperbolic N<sub>p</sub> = q<sub>i</sub> / [D(1&minus;b)] &times; [1 &minus; (1+bDt)<sup>1&minus;1/b</sup>].</div>`)}
  ${sec('Worked example',`<div class="worked"><p><b>Problem.</b> q<sub>i</sub> = 1,000 bbl/d, D = 0.35/yr, b = 0.5. What is the rate and cumulative production after 3 years?</p>
  <ol><li><code>1 + bDt = 1 + 0.5 &times; 0.35 &times; 3 = ${(1+0.5*0.35*3).toFixed(3)}</code></li>
  <li><code>q(3) = 1,000 / ${(1+0.5*0.35*3).toFixed(3)}<sup>2</sup> = ${fmt(q3)} bbl/d</code></li>
  <li>Cumulative: <code>N<sub>p</sub>(3) &asymp; ${fmt(Np3)} bbl</code>, about ${(Np3/1e6).toFixed(2)} million barrels.</li></ol></div>`)}
  ${sec('Try it',`
  <div class="lab"><div class="lab-grid">
    <div>${slider('qi','Initial rate q<sub>i</sub>',100,5000,50,1000)}${slider('D','Initial decline D',0.05,0.9,0.01,0.35)}${slider('b','Decline exponent b',0,1.5,0.05,0.5)}${slider('t','Time',0,10,0.1,3)}
    <div class="read">${readBox('rQ','Rate at this time')}${readBox('rNp','Cumulative production')}</div></div>
    <svg id="ch" class="chart" viewBox="0 0 560 320" role="img" aria-label="Production rate over time for exponential, harmonic and the chosen decline"></svg>
  </div><div class="btns"><button class="btn" id="play">Play time forward</button></div></div>
  <div class="callout">Try this: set b = 0 (exponential) and note the rate at year 5. Now raise b to 1 (harmonic) with the same D and qi, and compare: harmonic decline always predicts more oil left at any given time, which is why an overly generous b can overstate reserves.</div>`)}
  ${sec('Common mistakes',`<ul><li>Fitting b from only a few months of early data, before flow has settled into boundary-dominated decline. Early-time b estimates are notoriously unreliable.</li><li>Using b &gt; 1 without limit. Most regulators and reserves auditors require b to be capped (commonly at 1, sometimes higher for unconventional wells with documented justification) and switched to exponential decline once the well reaches a minimum economic rate.</li><li>Extrapolating decades past the data. Small errors in b compound badly over a long forecast.</li></ul>`)}
  ${sec('References',`<ul class="refs"><li>Arps, J.J. (1945). Analysis of decline curves. <em>Transactions of the AIME</em>, 160(1), 228&ndash;247.</li><li>Fetkovich, M.J. (1980). Decline curve analysis using type curves. <em>Journal of Petroleum Technology</em>, 32(6), 1065&ndash;1077.</li></ul>`)}`},
  mount(root){
    function upd(){
      const qi=+$('#qi',root).value,D=+$('#D',root).value,b=+$('#b',root).value,t=+$('#t',root).value;
      setOut(root,'qio',fmt(qi)+' bbl/d');setOut(root,'Do',(D*100).toFixed(0)+'%/yr');setOut(root,'bo',b.toFixed(2));setOut(root,'to',t.toFixed(1)+' yr');
      const qv=arpsQ(qi,D,b,t),Np=arpsNp(qi,D,b,t);
      setOut(root,'rQ',fmt(qv)+' bbl/d');setOut(root,'rNp',fmt(Np/1e6,2)+' MMbbl');
      const a=axes({w:560,h:320,x0:0,x1:10,y0:0,y1:qi,xs:2,ys:qi/5,xl:'Time (years)',yl:'Rate (bbl/d)'});
      const cur=[],exp=[],har=[];for(let tt=0;tt<=10;tt+=0.1){cur.push([a.sx(tt),a.sy(arpsQ(qi,D,b,tt))]);exp.push([a.sx(tt),a.sy(arpsQ(qi,D,0,tt))]);har.push([a.sx(tt),a.sy(arpsQ(qi,D,1,tt))])}
      let c=a.svg+`<path class="l-grey" d="${pathOf(exp)}"/><path class="l-grey" d="${pathOf(har)}"/><path class="l-brand" d="${pathOf(cur)}"/>`;
      c+=`<text class="tx" x="${a.sx(8)}" y="${a.sy(arpsQ(qi,D,0,8))-6}">b=0</text><text class="tx" x="${a.sx(8)}" y="${a.sy(arpsQ(qi,D,1,8))-6}">b=1</text>`;
      c+=`<line class="mk" x1="${a.sx(t)}" x2="${a.sx(t)}" y1="${a.sy(0)}" y2="${a.sy(qv)}"/><circle class="dot-b" cx="${a.sx(t)}" cy="${a.sy(qv)}" r="6"/>`;
      $('#ch',root).innerHTML=c;
    }
    $$('input',root).forEach(i=>i.addEventListener('input',upd));
    let stop=null;
    $('#play',root).addEventListener('click',()=>{
      if(stop){stop();return}const btn=$('#play',root);btn.textContent='Stop';let raf,t0=null;
      const fin=()=>{cancelAnimationFrame(raf);stop=null;btn.textContent='Play time forward'};
      const step=t=>{if(t0==null)t0=t;const k=clamp((t-t0)/5000,0,1);$('#t',root).value=(k*10).toFixed(1);upd();if(k<1)raf=requestAnimationFrame(step);else fin()};
      stop=regAnim(fin);raf=requestAnimationFrame(step);
    });
    upd();
  }
};
