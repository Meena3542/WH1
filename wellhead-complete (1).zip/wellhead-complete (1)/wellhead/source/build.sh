#!/usr/bin/env bash
# Rebuilds the two HTML files from the source pieces. Needs only bash.
set -e
cd "$(dirname "$0")"
cat app1.js app2.js app3.js app5.js app6.js app7.js app8.js app9.js app10.js app4.js > all.js
build(){ cat shell_head.html style.css shell_mid.html > "$2"; sed "s#const LIVE_API='';#const LIVE_API='$1';#" all.js >> "$2"; echo '</script></body></html>' >> "$2"; }
build '' ../standalone/wellhead.html
build '/api/feed' ../collector/public/index.html
rm all.js
echo "Built standalone/wellhead.html and collector/public/index.html"
